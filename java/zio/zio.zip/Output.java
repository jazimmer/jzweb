// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import java.io.*;
import java.util.*;
import java.text.NumberFormat;


/**
 * Provides for text output to files, command windows, sockets, 
 * character arrays, Strings, and <CODE>File</CODE> objects.
 * <P>
 * Use constructor with file name for file output and without
 * file name for System.out.
 * <P>Quick Usage:<P><PRE>
 * // This example outputs an int, a char, a double, and a String on the
 * // next line of the command window.
 *    Output outc = new Output();  
 *    outc.writeInt(2);
 *    outc.writeChar(' ');
 *    outc.writeDouble(2.2);
 *    outc.writeString(" -- that's all folks!");
 *    outc.writeEndOfLine();
 * // next example copies a file, line by line from "infile.txt" to 
 * // "outfile.txt" using the Input class with the Output class
 *     Input in = new Input("infile.txt");
 *     Output out = new Output("outfile.txt");
 *     for(;;) {
 *         String line = in.readLine();
 *         if( in.eof() ) break;
 *         out.writeLine(line);
 *     }
 *     in.close(); out.close();
 * </PRE><P>
 *
 * Of the <CODE>write...</CODE> methods, only 
 * the <CODE>writeLine</CODE> method is guaranteed to have finished
 * writing when execution moves on to something else.  This may be
 * a significant fact for you if your program terminates abnormally and
 * you are trying to figure out what managed to finish before your program 
 * got into trouble.
 * <Fl> <P>Flushing the output buffer is not automatic.  It happens only with
 * these methods: <CODE>writeLine, flush,</CODE> and <CODE>close</CODE>.
 * <P>Error behavior can be changed by subclassing the <CODE>Zio</CODE> class.
 * <P> Consider using the <CODE>File</CODE> class in conjunction with this
 * class; that way offers greater flexibility over the direct use of file names.</Fl>
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
 public class Output {

    private PrintWriter out;
    private static boolean append = false;

    private char [] copyLeftward( String what, int size ) {
         char [] cary = new char [size];
         int i = what.length()-1;
         int j = size-1;
         while( i>=0 && j>=0 ) cary[j--] = what.charAt(i--);
         while( j>=0 ) cary[j--]=' ';
         return cary;
    }

     private char [] copyRightward( String what, int size ) {
         char [] cary = new char [size];
         int i = 0;
         int j = 0;
         while( i<what.length() && j<size ) cary[j++] = what.charAt(i++);
         while( j<size ) cary[j++]=' ';
         return cary;
     }
     
    /**
     * Creates an Output object capable of writing to the command window.
     */
    public Output() {
        out = new PrintWriter( System.out, false );
    }

    /**
     * Creates an Output object capable of writing to the named file.  If file
     * already exists, it will be cleared of content first.
     * @param fileName the name of the file to be written on
     */
    public Output(String fileName) {
        try {
            out = new PrintWriter( new FileOutputStream(fileName,append), false );
        } catch (IOException e ) {
            Zio.error("Cannot open " + fileName,e);
        } finally {
            append = false;
        }
    }

    /**
     * Writes a character
     * @param writeMe the char to be written
     */
    public final void writeChar(char writeMe) {
        out.print(writeMe);
    }

    /**
     * Writes a String.  A "\n" within the String
     * will cause a new line of output to be begun. 
     * <Fl> However, unlike with System.out.print, the
     * output buffer will not be flushed.  That will
     * wait until close() or writeLine() has
     * executed. <Fl>
     * @param writeMe the String to be written
     */
    public final void writeString(String writeMe) {
        out.print(writeMe);
    }
    /**
     * Writes a <CODE>String</CODE> within a specified number
     * of columns.  The string will be truncated or padded
     * with blanks as necessary.
     * <Fl>  The <CODE>size</CODE> parameter may be negative, in which
     * case a string which does not require all <CODE>-size</CODE> columnns
     * will be right justified within its allotted size.  
     * Normally a string is left justified within its allotted
     * size.</Fl>
     * @param writeMe the <CODE>String</CODE> to be written
     * @param size the size of the output <CODE>String</CODE>
     */
    public final void writeString(String writeMe, int size) {
        if( size>=0 ) {
            out.print(copyRightward(writeMe,size));
        } else {
            out.print(copyLeftward(writeMe,-size));
        }
    }

    /**
     * Writes the character code(s) that signal the end of a line.
     * <FL><P>Flushes the output buffer.</FL>
     */
     public final void writeLine() {
         out.println(); out.flush();
    }

    /**
     * Writes a String and then writes the character code(s) that
     * signals the end of a line.
     * <FL><P>Flushes the output buffer.</FL>
     * @param line the string to be written as a line
     */
    public final void writeLine(String line) {
        out.println(line); out.flush();
    }
    
    /**
     * Writes an <CODE>int</CODE>.
     * @param writeMe The int to be converted to String form and written.
     */
    public final void writeInt(int writeMe) {
        out.print(writeMe);
    }

    /**
     * Writes a <CODE>double</CODE>.
     * @param writeMe The double to be converted to String form and written.
     */
    public final void writeDouble(double writeMe) {
        out.print(writeMe);
    }

    /**
     * Writes an int as a decimal number within
     * a specified number of columns.
     * <Fl>  The <CODE>size</CODE> parameter may be negative, in which
     * case a number which does not require all <CODE>-size</CODE> columnns
     * will be left justified within its allotted size.  
     * Normally the number is right justified within its allotted
     * size.</Fl>
     * <P> The <CODE>size</CODE> parameter must allow for at least two columns.
     * If the number does not fit into its allotted
     * space, it will be replaced with two exclamation marks.
     * @param writeMe the <CODE>int</CODE> to be written
     * @param size the number of characters actually output
     */
    public final void writeInt(int writeMe, int size) {
        int asize = Math.abs(size);
        if( asize<2 ) Zio.error(
            "size parameter must be >=2 for left justification and "+
            "<=-2 for right justification"
        );
        String str = Integer.toString(writeMe);
        if( str.length()>asize ) str = "!!";
        if( size>=0 )   {
            out.print(copyLeftward(str,size));
        } else {
            out.print(copyRightward(str,asize));
        }
    }
    
    /**
     * Writes a double in decimal form  within a specified number of 
     * columns and using a specified number of digits to the right of
     * the decimal point.
     * <Fl>  The <CODE>size</CODE> parameter may be negative, in which
     * case a number which does not require all <CODE>-size</CODE> columns
     * will be left justified within its allotted size.  
     * Normally the number is right justified within its allotted
     * size.</Fl>
     * <P> The <CODE>size</CODE> parameter must allow for at least two columns.
     * If the number does not fit into its allotted
     * space, it will be replaced with two exclamation marks.
     * @param writeMe the double to be converted to String form and written
     * @param fractionalDigits number of fractional digits desired
     * @param size the number of characters actually written
     */
    public final void writeDouble(
        double writeMe, int fractionalDigits, int size
    ) {
        int asize = Math.abs(size);
        if( fractionalDigits<0 || fractionalDigits>asize-1 ) {
            Zio.error("writeDouble's second parameter is number of fractional digits. " +
                  "Also the third parameter must be >=2 for left justification and "+
                  "<=-2 for right justification."
            );
        }
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMinimumFractionDigits(fractionalDigits);
        nf.setMaximumFractionDigits(fractionalDigits);
        String str = nf.format(writeMe);
        if( str.length()>asize ) str = "!!";
        if( size>=0 )   out.print(copyLeftward(str,size));
        else            out.print(copyRightward(str,asize));
    }

    /**
     * Tells operating system your program is finished writing.
     * <I>Always</I> close files when you are done with them.
     * Files can be reopened with by instantiating another <CODE>Input</CODE>
     * or <CODE>Output</CODE> object.
     */
    public final void close()  {
        out.close();
    }

    /**
     * Creates an Output object from any a File object.
     */
     public
    Output(File file) {
        try {
            out = new PrintWriter( new FileOutputStream(file,append), false );
        } catch (IOException e ) {
            Zio.error("Cannot open " + file.getName() + " for output",e);
        } finally {
            append = false;
        }
    }
    
    /**
     * Creates an Output object from any writer object.  Writer
     * objects include StringWriters and CharArrayWriters.
     */
    public Output(Writer writer) {
        out = new PrintWriter( writer, false );
    }
    /* */
        
    /**
     * Creates an Ouput object from any OutputStream object.
     * Use this constructor with sock.getInputStream()
     * to perform output to a Socket object.
     * @param stream any OutputStream object
     */    
    public Output( OutputStream stream ) {
       out = new PrintWriter( stream, false );
    }
    /* */
    
    /**
     * Makes the next file opening constructor create an object that
     * will append to an existing file.  Applies only to the next
     * use of <CODE>new Output(String fileName)</CODE> or 
     * <CODE>new Output(File file) </CODE>.
     */
    public static final void appendNextOpenFile() {
        append = true;
    }
    /* */
    
    /**
     * Flush the output buffer without bothering with <CODE>writeLine</CODE>.
     */
    public final void flush() { out.flush(); }
    /* */
}
 
 