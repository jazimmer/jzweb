// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import java.util.*;
import java.io.*;
import java.awt.image.*;
import javax.imageio.*;


/**
 * This class contains methods for reading and writing entire files:
 * either text files or image files.  If image files, the image type
 * must be jpg or png. Here is an example that reads in the contents
 * of the file <CODE>source.txt</CODE> and then copies that contents
 * to the file <CODE>target.txt</CODE>:
 * <P><CODE>String&nbsp;contents&nbsp;=&nbsp;InOut.readText("source.txt");
 * <BR>InOut.writeText("target.txt",contents);<BR></CODE>
 * <Fl><P> The read and write methods in this class were written to be
 * thread safe but this feature has not been tested.
 * <P> The image reading and writing methods can be used to convert
 * from one image type to another.</Fl>
 * <P> Error handling can be overridden by subclassing the <CODE>Zio</CODE> class.
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public class InOut {
    
//// instance & package ////    
    
    private static final class FileLocker {
        
        /* FileLocker locks other threads out of playing with
        a file that is being read or written.  It sets no 
        system or network level locks.
        */
        private static TreeSet paths = new TreeSet(); 
        
        synchronized boolean register(File file) {
            try {
                while( paths.contains(file.getPath()) ) wait();
            } catch ( InterruptedException ie ) {
                Zio.error("a read or write operation has been interrupted while " +
                          "waiting for permission to proceed.",
                          ie
                );
                return false;  
            }
            paths.add(file.getPath()); 
            return true;
        }
        
        synchronized void unregister(File file) {
            if( paths.remove(file.getPath()) ) notifyAll();
        }
    
    }
     
    private static FileLocker lock = new FileLocker();
    
    private static String extractExtension( String name ) {
        int i = name.lastIndexOf('.');
        if( i==-1 ) return "";
        return name.substring( i ).toLowerCase();
    }

//// public & final ////    
    
    /**
     * Tests whether file can be written.
     * <Fl> Note this is not the same test as performed
     * by the <CODE>canWrite()</CODE> method in Java's <CODE>File</CODE>
     * class. </Fl>
     * @param fileName a file name
     * @return true iff named file can be written
     */
    public static final boolean canWrite(String fileName) {
        return canWrite(new File(fileName));
    }
    
    /**
     * Tests whether file can be written.
     * <Fl> Note this is not the same test as performed
     * by the <CODE>canWrite()</CODE> method in Java's <CODE>File</CODE>
     * class. </Fl>
     * @param file a <CODE>File</CODE> object
     * @return true iff indicated file can be written
     */
     public 
    static final boolean canWrite(File file) {
        File parent = file.getParentFile();
        return 
            (file.exists() && file.canWrite()) ||
            (!file.exists() && 
              (parent==null || (parent.isDirectory() && parent.canWrite())));
    }
    
    /**
     * Tests whether file can be written.
     * Checks two things: Can the file be written?  And,
     * is the image format indicated by the extension
     * supported?
     * @param fileName a file name
     * @return true iff named file can be written
     */
    public static final boolean canWriteImage(String fileName) {
        return canWriteImage(new File(fileName));
    }
    
    /**
     * Tests whether file can be written.
     * Checks two things: Can the file be written?  And,
     * is the image format indicated by the extension
     * supported?
     * @param file a <CODE>File</CODE> object
     * @return true iff indicated file can be written 
     */
     public 
    static final boolean canWriteImage(File file) {
        String ext = extractExtension(file.getName());
        return (ext.equals(".jpg") || ext.equals(".png")) && canWrite(file);
    }
    
    /**
     * Tests whether file can be read.
     * @param fileName a file name
     * @return true iff named file can be read 
     */
    public static final boolean canRead(String fileName) {
        return canRead(new File(fileName));
    }
    
    /**
     * Tests whether file can be read.
     * @param file a <CODE>File</CODE> object
     * @return true iff indicated file can be read
     */
    public 
    static final boolean canRead(File file) {
        return file.canRead();
    }
    
    /**
     * Tests whether file can be read.
     * Checks two things: Can the file be read?  And,
     * is the image format indicated by the extension
     * supported?
     * @param fileName a file name
     * @return true iff named file can be read
     */
    public static final boolean canReadImage(String fileName) {
        return canReadImage(new File(fileName));
    }
    
    /**
     * Tests whether file can be read.
     * Checks two things: Can the file be read?  And,
     * is the image format indicated by the extension
     * supported?
     * @param file a <CODE>File</CODE> object
     * @return true iff indicated file can be read 
     */
     public 
     static final boolean canReadImage(File file) {
        String ext = extractExtension(file.getName());
        return 
         (ext.equals(".jpg") || ext.equals(".png") || ext.equals(".gif"))
            &&
         file.canRead();
    }
    
    /**
     * Read a text file into a String.
     * Reads an entire file.  Meant to use for short text files.
     * @param fileName the name of the file to be read
     * @return a <CODE>String</CODE> containing the entire contents of the file
     */
    public static final String readText( String fileName ) {
        File f = new File(fileName);
        return readText(f);
    }
    
    /**
     * Read a text file into a String.
     * Reads an entire file.  Meant to use for short text files.
     * @param file a <CODE>file</CODE> object identifying the file to be read
     * @return a <CODE>String</CODE> representing the entire contents of the file
     */
      public
    static final String readText( File file ) { 
        if( file==null ) {
            Zio.error("InOut.readText requires a <CODE>file</CODE> object.");
        }
        if( file.length()>Integer.MAX_VALUE ) Zio.error("file is too long");
        if( !lock.register(file) ) return null;
        BufferedReader in = null;
        int where = 0;
        String retval = null;
        try {
            in = new BufferedReader( new FileReader(file) );
            where = 1;
            StringBuffer myBuffer = new StringBuffer( (int)(file.length()) );
            for (;;) {
                char [] cary = new char [1024];
                int charCount = in.read(cary,0,1024);
                if( charCount==-1 ) break;
                myBuffer.append(cary,0,charCount);
            }
            where = 2;
            in.close();
            retval = new String(myBuffer);
            lock.unregister(file);
        } catch (IOException e) {
            if( where==1 ) try { in.close(); } catch( Exception ex ) { }
            lock.unregister(file);
            if( where==0 ) {
                Zio.error("cannot open " + file.getPath() + " for reading");
            } else if(where==1) {
                Zio.error("cannot read " + file.getPath());
            } else if(where==2) {
                Zio.error("cannot close " + file.getPath());
            }
        }
        return retval;        
    }
   
     /**
      * Writes a String to a file.
      * Meant to be used for short text files.  The string will become
      * the entire contents of the file.  
      * @param fileName the name of the file to be written
      * @param content the new contents of the named file
      */
    public static final void writeText( String fileName, String content ) {
        writeText( new File(fileName), content );
    }

    /**
     * Writes a String to a file.
     * Meant to be used for short text files.  The string will become
     * the entire contents of the file.  
     * @param file a <CODE>file</CODE> object identifying the file to be written on
     * @param content the new contents of the named file
     */
     public
    static final void writeText(File file, String content) {
        if( file==null ) {
            Zio.error("InOut.writeText requires a <CODE>file</CODE> object.");
        }
        if( file.length()>Integer.MAX_VALUE ) Zio.error("file is too long");
        int where = 0;
        if( !lock.register(file) ) return;
        PrintWriter out = null;
        try {
            out = new PrintWriter( new FileOutputStream(file), true );
            where = 1;
            out.print(content);
            where = 2;
            out.close();
            lock.unregister(file);
        } catch( IOException e ) {
            if( where==1 ) try { out.close(); } catch( Exception ex ) { }
            lock.unregister(file);
            if( where==0 ) {
                Zio.error("cannot open " + file.getPath() + " for writing");
            } else if(where==1) {
                Zio.error("cannot write " + file.getPath());
            } else if(where==2) {
                Zio.error("cannot close " + file.getPath());
            }
        }
    }
    
    /**
     * Reads a gif, jpg or png image.
     * <BR>You must import <CODE>java.awt.image.BufferedImage</CODE>
     * to use this.
     * @param fileName the name of the image file to be read, must end with .jpg or
     * .png
     * @return the image in <CODE>BufferedImage</CODE> form
     */
    public static final BufferedImage readImage(String fileName) {
        return readImage( new File( fileName ) );
    }
    
    /**
     * Reads a gif, jpg or png image.
     * <BR>You must import <CODE>java.awt.image.BufferedImage</CODE>
     * to use this.
     * @param file a <CODE>file</CODE> object referencing the file to be read;
     * file name must end with .jpg or .png.
     * @return the image in <CODE>BufferedImage</CODE> form
     */
     public
    static final BufferedImage readImage(File file) 
    {
        if( file==null ) {
            Zio.error("InOut.readImage requires a <CODE>file</CODE> object.");
        }
        if( file.length()>Integer.MAX_VALUE ) Zio.error("file is too long");
        if( !lock.register(file) ) return null;
        BufferedImage pic = null;
        int where = 1;
        try {
            if( !canReadImage(file) ) throw new IOException();
            where = 1;
            pic = ImageIO.read(file); // (file.toURL());
            where = 3;
            if( pic==null ) throw new IOException();
            lock.unregister(file);
        } catch( IOException e ) { 
            lock.unregister(file);
            if( where==0 ) {
                Zio.error("cannot open " + file.getPath() +
                          " for reading or its extension is not supported");
            } else if(where==1) {
                Zio.error("cannot read " + file.getPath());
            } else if(where==3) {
                Zio.error("some aspect of the image processing API is missing");
            }
        }
        return pic;
    }
    
    /**
     * Writes a jpg or png image.
     * <BR>You must import <CODE>java.awt.image.BufferedImage</CODE>
     * to use this.
     * @param fileName the name of the file to be written;
     * must end with .jpg or .png
     * @param content the image in <CODE>BufferedImage</CODE> form
     */
    public static final void writeImage
        (String fileName, BufferedImage content) 
    {
        writeImage( new File( fileName), content );
    }
    
    /**
     * Writes a jpg or png image.
     * <BR>You must import <CODE>java.awt.image.BufferedImage</CODE>
     * to use this.
     * @param file a <CODE>file</CODE> object referencing the file to be written;
     * file name must end with .jpg or .png
     * @param content the image in <CODE>BufferedImage</CODE> form
     */
     public
    static final void writeImage(File file, BufferedImage content) {
        if( file==null || content==null) {
            Zio.error(
                "InOut.writeImage requires a <CODE>file</CODE> object " +
                "and a nonnull image."
            );
        }
        if( file.length()>Integer.MAX_VALUE ) Zio.error("file is too long");
        if( !lock.register(file) ) return;
        int where = 0;
        try {
            if( !canWriteImage(file) ) throw new IOException();
            where = 1;
            String type = extractExtension(file.getName()).substring(1);
            boolean OK_Type = ImageIO.write(content,type,file);
            lock.unregister(file);
            where = 3;
            if( !OK_Type ) throw new IOException();
        } catch( IOException e ) {
            lock.unregister(file);
            if( where==0 ) {
                Zio.error("cannot open " + file.getPath() +
                          " for writing or its extension is not supported");
            } else if(where==1) {
                Zio.error("cannot write " + file.getPath());
            } else if(where==3) {
                Zio.error("some aspect of the image processing API is missing");
            }
        }
    }
    
    /**
     * used for testing, may be arbitrarily changed
     */
    public 
     static void main ( String [] files ) {
        if( files.length!=2 ) Zio.error("usage: source destination");
        if( !canRead(files[0]) ) Zio.abort("cannot read " + files[0] );
        if( !canWrite(files[1]) ) Zio.abort("cannot write " + files[1] );
        String extension = files[0].substring( files[0].length()-4 ).toLowerCase();
        if( extension.equals(".jpg") || extension.equals(".png") ) {
            BufferedImage buf = readImage(files[0]);
            writeImage(files[1],buf);
        } else {
            String str = readText(files[0]);
            writeText(files[1],str);
        }
        Zio.show("This behavior is undocumented and may change.");
    }
    
}


/*

notice that the following will test what ImageWriters are available
Iterator i = ImageIO.getImageWritersBySuffix("gif");
while(i.hasNext()) {
InOut.show(
((ImageWriter)(i.next())).toString()
);
}

Last time i did the test we could read but not write gifs

-- jaz

*/
