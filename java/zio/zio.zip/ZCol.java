/// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax.swing.*;
import java.awt.*;

/**
 * A <CODE>ZCol</CODE> is a vertical slice of a part of a window.
 * A <CODE>ZCol</CODE> is almost identical to a <CODE>ZRow</CODE>. One can 
 * be obtained
 * from the other by transposing the horizontal and vertical
 * directions.  Both are <CODE>ZObject</CODE>s.
 * A <CODE>ZCol</CODE> will stretch in a vertical direction
 * when the user expands a window.  If none of the <CODE>ZObject</CODE>s
 * in a column expands vertically, the expansion will happen in the spaces
 * around the <CODE>ZObject</CODE>s; otherwise it happens in those
 * <CODE>ZObject</CODE>s.  (Those which can expand vertically.)   
 * If any nonexpanding component <CODE>ZObject</CODE> is too narrow for 
 * the others, it will be centered horizontally within the column
 * It you don't like this, you can get position that <CODE>ZObject</CODE>
 * to the left or right by putting a <CODE>ZRow</CODE> around it.
 * and using <CODE>atRight()</CODE> or <CODE>atLeft()</CODE>.
 * <P>By default, <CODE>ZCol</CODE> will not expand horizontally even
 * if some object within it is capable of horizontal expansion.
  * Think of this default state as "half locked". Vertical
 * expansion <I>will</I> happen even if none of the component
 * <CODE>ZObject</CODE>s expands vertically.  Horizontal expansion
 * will <I>not</I> happen even if some of the component objects
 * expand horizontally.  From
 * this half-locked, state you can use the <CODE>unlock()</CODE> suffix
 * to unlock expansion horizontally or the <CODE>lock()</CODE> suffix to
 * lock expansion vertically.  The <CODE>lock</CODE> suffix overrides
 * the unlock suffix.
 * @see <A HREF="../../slices.html" TARGET="_top">about slices</A>
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
class ZCol extends ZSlice {
    
//// private & instance ////

    private int space = -1;
  
//// public and final ////    
    
    /**
     * Create a <CODE>ZCol</CODE> with multiple objects given in an array.
     * The objects of <CODE>ZCol</CODE> will appear from top to bottom
     * in the order
     * <CODE>gs[0]</CODE>, <CODE>gs[1]</CODE>, ... .
     * @param gs an array of those <CODE>ZObjects</CODE> which will appear
     * in the column
     */
     public ZCol( ZObject [] gs ) {
        this.gs = gs;
    }
    
     /**
      * Create a <CODE>ZCol</CODE> with a single <CODE>ZObject</CODE>.
      * @param gu the object to appear in the column
      */
     public ZCol( ZObject gu ) {
        ZObject [] gs = { gu };
        this.gs = gs;
    }

     /**
      * Create a <CODE>ZCol</CODE> with two <CODE>ZObject</CODE>s.
      * The parameters are listed left to right in the top to bottom order
      * of the column.
      * @param gu1 the topmost <CODE>ZObject</CODE>
      * @param gu2 the bottommost <CODE>ZObject</CODE>
      */
    public ZCol( ZObject gu1, ZObject gu2 ) {
        ZObject [] gs = { gu1, gu2 };
        this.gs = gs;
    }

    /**
     * Create a <CODE>ZCol</CODE> with three <CODE>ZObject</CODE>s.
     * The parameters are listed left to right in the top to bottom order
     * of the column.
     * @param gu1 the topmost <CODE>ZObject</CODE>
     * @param gu2 the middle <CODE>ZObject</CODE>
     * @param gu3 the bottommost <CODE>ZObject</CODE>
     */
    public ZCol( ZObject gu1, ZObject gu2, ZObject gu3 ) {
        ZObject [] gs = { gu1, gu2, gu3 };
        this.gs = gs;
    }

    /**
     * Create a <CODE>ZCol</CODE> with four <CODE>ZObject</CODE>s.
     * The parameters are listed left to right in the top to bottom order
     * of the column.
     * @param gu1 the topmost <CODE>ZObject</CODE>
     * @param gu2 the top middle <CODE>ZObject</CODE>
     * @param gu3 the bottom middle <CODE>ZObject</CODE>
     * @param gu4 the bottommost <CODE>ZObject</CODE>
     */
    public ZCol( ZObject gu1, ZObject gu2, ZObject gu3, ZObject gu4 ) {
        ZObject [] gs = { gu1, gu2, gu3, gu4 };
        this.gs = gs;
    }
    
    /**
     * Suffix that creates debug output.
     */
    public ZCol debug( String debugId ) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }
    
    /**
     * Suffix that forces top component <CODE>ZObject</CODE> to 
     * appear at top of column without intervening
     * space.
     */
    public final ZCol atTop() { 
        suffixChek();
        spaceAtFirst = false;
        return this; 
    }
    

    /**
    * Suffix that forces bottom component <CODE>ZObject</CODE> to 
    * appear at bottom of column without any
    * intervening space.
    */
    public final ZCol atBottom() { 
        suffixChek();
        spaceAtLast = false;
        return this; 
    }
    
    /**
     * Suffix that permits column to expand horizontally.
     * There is no spacing or padding to make horizontal
     * expansion work so it won't happen unless one of
     * the contained <CODE>ZObject</CODE>s already expands horizontally.
     * <P>If any other <CODE>ZObject</CODE> is too narrow
     * for the expanded column, it will be aligned in the center
     * of the column.  You can get around that by putting such
     * an object in a <CODE>ZRow</CODE> and using <CODE>atLeft()</CODE> or 
     * <CODE>atRight()</CODE>.
     */
    public final ZCol unlock() {
        suffixChek();
        unlocked = true;
        return this;
    }
    
    /**
     * Causes column to be unexpandable in any
     * direction.   Causes the <CODE>unlock()</CODE> 
     * suffix to be ignored.
     */
    public final ZCol lock() {
        locked = true;
        return this;
    }
    
    /**
     * Suffix that determines the background 
     * color of the column.  The background
     * color will be seen in the spaces and
     * will be inherited by the contained <CODE>ZObject</CODE>s.
     * @param c the desired color
     */
    public final ZCol background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }
    
    /** Suffix that sets the foreground color of
     * the column.  The foreground color will be
     * inherited by the contained <CODE>ZObject</CODE>s.
     */
    public
    final ZCol foreground( Color c ) {
        suffixChek();
        desiredForeground = c;
        return this;
    }
    
    
    /**
     * Suffix that sets minimum spacing. 
     * This suffix sets a minimum number of pixels for 
     * the height of a space.  If not present, this
     * minimum number is calculated with a complex
     * formula.<P>
     * This minimum always applies to space between
     * component <CODE>ZObject</CODE>s.  It applies to
     * space at top and bottom only if no <CODE>framed()</CODE>,
     * <CODE>unframed()</CODE>, 
     * <CODE>atTop()</CODE>, or <CODE>atBottom()</CODE> suffix has been
     * used.
     */
    public final ZCol space(int space) {
        suffixChek();
        this.space =  Math.max(0,space); 
        return this;
    }
    
    /** This suffix causes all component <CODE>ZObject</CODE>s to be
     * the same size.  No component object can be a slice.. 
     * The calculated size will be the smallest that
     * can accommodate the minimum size of all objects.
     * Causes <CODE>expandH()</CODE> and <CODE>expandV()</CODE> to be ignored.
     */
    public final ZCol uniform() {
         suffixChek();
         uniform = true;
         return this;
    }
    
    /** Suffix that creates an etched frame around the <CODE>ZCol</CODE>.
     * This margin overrides any other spacing on the sides
     * of the slice.  Do not use with <CODE>unframed()</CODE> suffix.
     * @param margin size of margin between the slice and the frame
     */
    public ZCol framed( int margin ) {
        suffixChek();
        if( this.margin>=0 ) Zio.abort(
            "use only one of framed() and unframed()" );
        frameType = 1;
        this.margin = Math.max(0,margin);
        return this;
    }

   /** Suffix that creates the margin used with a frame without
     * creating the frame.
     * This margin overrides any other spacing on the sides
     * of the slice. Do not use with <CODE>framed()</CODE> suffix.
     * @param margin size of margin around the slice
     */
    public ZCol unframed( int margin ) {
        suffixChek();
        if( this.margin>=0 ) Zio.abort(
            "use only one of framed() and unframed()" );
        this.margin = Math.max(0,margin);
        return this;
    }
    /** Suffix that creates a grid, or two dimensional
    * array, of <CODE>ZObject</CODE>s.  <CODE>ZObject</CODE>s in any one
    * row are forced to have the same height and <CODE>ZObject</CODE>s
    * in any one column are forced to have the same width.
    * <P> To make the grid, you must populate this <CODE>ZCol</CODE>
    * only with <CODE>ZRows</CODE>s and each row must have the
    * same number of <CODE>ZObject</CODE>s.
    * <P> The only suffixes that work with <CODE>grid()</CODE> are
    * <CODE>foreground()</CODE>, <CODE>background()</CODE>, <CODE>space()</CODE>, 
    * <CODE>framed()</CODE>, <CODE>unframed()</CODE>,  and <CODE>debug()</CODE>.
    * The only suffix that will work on any the <CODE>ZRow</CODE>s that
    * define the rows of this grid is <CODE>debug()</CODE>.  Suffixes 
    * work as normal on the <CODE>ZObject</CODE>s in the grid.
    * <P> NOT YET IMPLEMENTED.
    */
    public ZCol grid() { return this; }

    //// superclass redefinition ////
    
    String name() { return "ZCol"; }
    
    final void piecesAndSizes(ZObjects all) {
        if( !setupDone() ) {
            // SETUP COMPONENTS
            int height = 0;              // becomes max of minD.heights
            int width = 0;               // becomes max of minD.widths
            for( int i=0; i<gs.length; i+=1 ) {
                gs[i].setup(desiredForeground,desiredBackground,all);
                Dimension d = gs[i].minD;
                width = Math.max( width, d.width );
                height = Math.max( height, d.height );
            }
            if( uniform ) {
                Dimension uniD = new Dimension ( width, height );
                for( int i=0; i<gs.length; i+=1 ) {
                    if( !gs[i].atomic ) 
                        Zio.abort(
                           "uniform slices cannot contain slices"
                        );
                    gs[i].resize(uniD,uniD);
                }
            }
    
            // DETERMINE values for parameters
            int maxWidth = 0;          // becomes max of maxD.widths
            int maxHeight = 0;         // becomes max of maxD.heights
            int totalHeight = 0;       // becomes total of minD.widths 
            for( int i=0; i<gs.length; i+=1 ) {
                totalHeight += gs[i].minD.height;
                maxWidth = Math.max( maxWidth, gs[i].maxD.width );
                maxHeight = Math.max( maxHeight, gs[i].maxD.height );
            }
            int spaceHeightMn = 
                (space>=0) ?
                    space : 
                    Math.min( 
                        Zio.getScreenSize().height/4,
                        Math.max(3, (int)(totalHeight/(4.0*gs.length)))
                    );
            if( margin >= 0 ) { spaceAtFirst = spaceAtLast = false;  }
            if(locked) unlocked = false;
            totalHeight += (gs.length-1)*spaceHeightMn;
            if( spaceAtFirst ) totalHeight += spaceHeightMn;
            if( spaceAtLast ) totalHeight += spaceHeightMn;
            sliceMn.setSize( width, totalHeight );
            spaceMn.setSize( width, spaceHeightMn );
            boolean spacesExpand = maxHeight!=Zio.MAX;
            boolean horizontalExpansionWanted = maxWidth==Zio.MAX;
            sliceMaxDelta = new Dimension(
                (unlocked && horizontalExpansionWanted ? Zio.MAX : 0),
                (!locked ? Zio.MAX : 0)
            );
            spaceMaxDelta = new Dimension(
                (unlocked && horizontalExpansionWanted ? Zio.MAX : 0),
                (spacesExpand && !locked ? Zio.MAX : 0)
            );
            
        }  // end if( !setupDone() )
        
        aboutComponents = 
            "has " + gs.length + " objects with minimum space " +
            spaceMn.height;
        
        // CREATE
        setJCom( new SizableJPanel() );
        setSize( sliceMn );
        setMaxSize(Zio.maxD( sliceMaxDelta, sliceMn ));
        getJCom().setLayout( 
            new BoxLayout( getJCom(), BoxLayout.Y_AXIS ) 
        );
    }
    
}


// seting a horizontal alignment was tried but it distorted
// the aspect rations;  the same effect without the distortion
// is obtainable by putting a column in a row
