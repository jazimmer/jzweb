// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax .swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;

/**
 * The <CODE>Zio</CODE> class  is a method defining class that
 * contains a potpourri of methods.  Some
 * of these aid the other classes in the zio package.
 * Others provide a one stop shopping place for beginners looking
 * for a few simple actions to use in conjunction with the
 * zio package. 
 * @see <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Dimension.html" TARGET="_top">Dimension
 </A>, <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Color.html" TARGET="_top">Color</A>
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
 public class Zio {

//// for instance, class, and package ////
    
    static final int MAX =  Short.MAX_VALUE;
    static final Color NOCOLOR = new Color(0,0,0);

    private static Dimension ScreenSize = null; 
    private static Dimension ScrollBarSize = null;
    private static Color defaultForeground = NOCOLOR; 
    private static Color defaultBackground = NOCOLOR;
    private static Color desiredForeground = NOCOLOR; 
    private static Color desiredBackground = NOCOLOR;
    private static int horizontalInset = 0;
    private static Dimension emptyJFrameSize = null;
    private static int verticalInset = 0;
    private static boolean needsInitialize = true;
    private static ZioShutdown shutdown = new ZioShutdown();

    private static final void initialize() {
        Toolkit kit = Toolkit.getDefaultToolkit();
        JLabel temp = new JLabel("hi");
        if( defaultForeground==NOCOLOR ) defaultForeground = temp.getForeground();
        if( defaultBackground==NOCOLOR ) defaultBackground = temp.getBackground();
        if( desiredForeground==NOCOLOR ) desiredForeground = defaultForeground;
        if( desiredBackground==NOCOLOR ) desiredBackground = defaultBackground;
        JScrollBar jb1 = new JScrollBar(JScrollBar.VERTICAL,2,1,1,4);
        JScrollBar jb2 = new JScrollBar(JScrollBar.HORIZONTAL,2,1,1,4);
        ScrollBarSize = new Dimension( 
            jb1.getPreferredSize().width, 
            jb2.getPreferredSize().height 
            );
        ScreenSize = kit.getScreenSize();
        JFrame jtmp = new JFrame();
        jtmp.pack();
        emptyJFrameSize = jtmp.getPreferredSize();
        jtmp.dispose();
        needsInitialize = false;
    }
    
    static boolean dimensionsBad( Dimension d1, Dimension d2 ) {
        return  d1==null || d2==null ||
            d1.width<=0 || d2.width<=0 || d1.height<=0 || d2.height<=0 ||
            d1.width>d2.width || d1.height>d2.height;
    }
    
    private static boolean eqC( Color c1, Color c2 ) {
        return c1.getRed()==c2.getRed() && 
               c1.getGreen()==c2.getGreen() && 
               c1.getBlue()==c2.getBlue();
    }
    
    static final String colorToStr ( Color c ) {
        String cn;
        if( eqC(c,Color.RED) ) cn = "red";
        else if( eqC(c,Color.WHITE) ) cn = "white";
        else if( eqC(c,Color.BLUE) ) cn = "blue";
        else if( eqC(c,Color.BLACK) ) cn = "black";
        else if( eqC(c,Color.GRAY) ) cn = "gray";
        else if( eqC(c,Color.YELLOW) ) cn = "yellow";
        else if( eqC(c,Color.GREEN) ) cn = "green";
        else cn = c.toString();
        return cn;
    }

    static final void printInsets( Insets i, String Name  ) {
        System.out.println(
            Name + "insets: " + i.top +","+i.left+","+i.bottom+","+i.right );
    }

    static void pIfNull(String s, Object o) {
        if(o==null) { System.out.println(s); System.out.flush(); }
    }

    static String p( String s ) {
        System.out.print(s); System.out.flush(); return s;
    }

    static final void cleanup() {
        shutdown.cleanupAction();
    }
    
    static final void error(String msg) {
        shutdown.errorAction(msg,null);
    }
    
    static final void error(String msg, Exception e) {
        shutdown.errorAction(msg,e);
    }

//// public & final ////

    /**
     * Finds the size of an empty window under the
     * current operating system.
     * @return a <CODE>Dimension</CODE> giving the empty window size.
     */
    
    static final Dimension getEmptyWindowSize() {
        if( needsInitialize ) initialize();
        return emptyJFrameSize;
    }
    
    /**
     * Finds the size of the largest <CODE>ZObject</CODE> that will
     * fit on this screen with this motif.
     * @return largest usable dimension of a <CODE>ZObject</CODE>
     */
   public  static final Dimension getLargestZObject() {
        if( needsInitialize ) initialize();
        return new Dimension(
            ScreenSize.width - emptyJFrameSize.width + 4,
            ScreenSize.height - emptyJFrameSize.height
        );
    }
    
    /**
     * Finds the size in pixels of the current
     * moniter.  If the computer executing this code
     * has more than one monitor, the default one
     * is used.
     * @return a <CODE>Dimension</CODE> giving the screen size
     */
    public static final Dimension getScreenSize() { 
        if( needsInitialize ) initialize();
        return ScreenSize; 
    }

    static Dimension maxD( Dimension d1, Dimension d2 ) {
        return new Dimension(
            (d1.width>d2.width) ? d1.width : d2.width,
            (d1.height>d2.height) ? d1.height : d2.height
        );
    }
    
    static Dimension timesD( Dimension d, double factor ) {
        return new Dimension(
                  (int)(factor*d.width+0.4),
                  (int)(factor*d.height+0.4)
        );
    }
    
    static Dimension addD( Dimension d1, Dimension d2 ) {
        return new Dimension(
                d1.width+d2.width,
                d1.height+d2.height
        );
    }
    
    static Dimension copyD( Dimension d ) {
        if( d==null ) return null;
        return new Dimension( d.width, d.height );
    }
    
    static Color copyC( Color c ) {
        if( c==null ) return null;
        return new Color(
            c.getRed(), c.getGreen(), c.getBlue()
        );
    }
    
    static final Dimension getScrollBarThickness() { 
        if( needsInitialize ) initialize();
        return ScrollBarSize; 
    }
    
    static final Font changePointSize(Font f, int pointSize) {
        return new Font(f.getFamily(), f.getStyle(), pointSize);
    }

    /**
     * Get the default foreground color.  This
     * is the foreground color your
     * objects will have if you do  not execute.
     * <CODE>setGlobalForeground()</CODE> or some 
     * relevant suffix.  Foreground is the color
     * used when printing and drawing on the
     * screen.
     * @return the default foreground color
     */
     public 
    static final Color getOriginalGlobalForeground() { 
        if( needsInitialize ) initialize(); 
        return defaultForeground; 
    }
    
    /**
     * Get the default background color.  This
     * is the background color your system would
     * give your objects if you do not execute
     * <CODE>setGlobalBackground()</CODE> or some 
     * relevant suffix.
     */
     public 
    static final Color getOriginalGlobalBackground() { 
        if( needsInitialize ) initialize();
        return defaultBackground; 
    }
    
    /**
     * Get the global foreground color. This
     * color may be overriden with suffixes.
     * @return the global foreground color
     */
     public 
    static final Color getGlobalForeground() { 
        if( needsInitialize ) initialize(); 
        return desiredForeground; 
    }
    
    /**
     * Get the global background color.
     * This color may be overriden with 
     * suffixes.
     * @return the global background color
     */
     public 
    static final Color getGlobalBackground() { 
        if( needsInitialize ) initialize();
        return desiredBackground; 
    }
    
    /**
     * Sets the global foreground color.
     * This color may be overriden with 
     * suffixes; otherwise it applies to
     * every ZObject in a ZWindow.
     * @see <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Dimension.html" TARGET="_top">Dimension
     </A>, <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Color.html" TARGET="_top">Color</A>
     * @param fg a new global foreground color
     */
    public 
    final static void setGlobalForeground( Color fg ) {
       desiredForeground = Zio.copyC(fg);
    }
    
    /**
     * Set the global background color.
     * This color may be overriden with 
     * suffixes; otherwise it applies to
     * every ZObject in a ZWindow.
     * @see <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Dimension.html" TARGET="_top">Dimension
     </A>, <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Color.html" TARGET="_top">Color</A>
     * @param bg a new global background color
     */
    public 
    final static void setGlobalBackground( Color bg ) {
        desiredBackground = Zio.copyC(bg);
    }
    
    /**
     * Registers a subclass of ZioShutdown to change
     * the actions taken under normal and abnormal
     * shutdowns.  See the ZioShutdown class.
     * @param g a subclass of ZioShutdown
     */
     public
    static void registerShutdown( ZioShutdown g ) {
        shutdown = g;
    }
     
    /**
     * Writes a string in the command window and starts a new
     * line.
     * <Fl> This is a <CODE>String</CODE> replacement for 
     * <CODE>System.out.println</CODE> that is 
     * included for the convenience of beginners using
     * the <CODE>InOut.readText()</CODE> method. </Fl>
     * @param str the string to be written
     */
    public final static void show(String str) {
        System.out.println(str); System.out.flush();
    }

    /**
     * Writes a message in the command window,
     * starts a new line, and aborts the program.
     * <Fl> Calls a cleanup method before aborting, see
     * the shutdown class where you can arrange
     * your programs to recover from errors.</Fl>
     * @param message the string to be written
     */
    public final static void abort(String message) {
        shutdown.errorAction(message,null);
    }
    
    /**
     * Stops the program.
     * <Fl> Calls a cleanup method before stopping, see
     * the ZioShutdown class. </Fl>
     */
    public final static void stop() {
        shutdown.cleanupAction();
        System.exit(0);
    }
    
    /** Splits a <CODE>String</CODE> into a character array.
     * This method included for the convenience of beginners
     * using the <CODE>InOut.readText()</CODE> method.  All characters
     * including end of line symbols will be placed into the
     * returned character array.  <Fl>Note that
     * <P><CODE>new String( Zio.extractChars(str))</CODE><P>
     * will return a <CODE>String</CODE> with the same <CODE>char</CODE>s in the
     * same order as <CODE>str</CODE>.</Fl>
     * @param str a string
     * @return an array of all the characters in str
     */
    public final static char [] extractChars(String str) {
        char [] retval = new char [str.length()];
        for(int i=0; i<str.length(); i+=1) retval[i] = str.charAt(i);
        return retval;
    }
    
    /** Splits a <CODE>String</CODE> into an array of lines.
     * Lines are returned in an array of <CODE>String</CODE>s
     * without their end of line symbols.
     * Note an empty file or a file containing one empty
     * line will produce an array with one empty string in it.
     * @param str a string
     * @return an array of all the lines in str
     */
    public final static String [] extractLines(String str) {
        String [] tary = str.split("\n");
        if( tary.length==0 ) {
            tary = new String[1];
            tary[0] = "";
        }
        return tary;
    }
    
    /**
     * Pops a window up that asks a yes/no question.
     * @param question the question to ask the user
     * @return true if user answers "yes" and false if user 
     * answers "no" or closes the window
     */
    public static boolean ask( String question ) {
        int ans = JOptionPane.showConfirmDialog(
            null,
            question + "?",
            "Query",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null
         );
         return ans==JOptionPane.YES_OPTION;
    }
    
    /**
     * Pops a window up that tells the user something.
     * User is presented with a message and a button 
     * that says "message seen".
     * @param message a warning message
     */
    public static void tell( String message ) {
        String [] options = { "Message Seen" };
        JOptionPane.showOptionDialog(
            null,
            message,
            "Message",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.WARNING_MESSAGE,
            null,
            options,
            null
         );
    }
    
    /** Splits a <CODE>String</CODE> into an array of tokens.
     * Think of a token as a word.  (Actually a token can contain
     * punctuation characters as well as letters)  This method
     * is included for the convenience of beginners using 
     * <CODE>InOut.readText()</CODE>. <Fl> <P>  A more careful definition of a
     * token is that it is a string consisting of characters that 
     * are not seen as whitespace.  (That means ' ', '\n', and
     * '\t' are excluded.)  This method finds all the longest
     * possible tokens in its argument and returns them 
     * in order as an array of <CODE>String</CODE>s. </Fl>
     * @param str a string
     * @return an array of all the tokens in str
     */
    public final static String [] extractTokens(String str) {
        return str.split("[ \n\t]+");
    }

}
