// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * A program writeable two-dimensional text area.
 * Your program can write in this area and your user can
 * select text within it.  Your user cannot write in it.
 * The initial size of the area remains in effect whenever
 * the text is rewritten unless the user is able to change
 * it because you used the <CODE>expandH()</CODE> or <CODE>expandV()</CODE>
 * suffixes.
 * If the initial text doesn't define as big an area as
 * you will need later, use <CODE>numRowCols()</CODE> 
 * suffix and/or the <CODE>minSize()</CODE> suffix to ask for more.  
 * Initial text area will be the smallest which accommodates
 * all size information provided by these suffixes and
 * the initial text (if any).
 * <P>
 * If rewritten text does not fit in text area, it is truncated.  
 * If this is a problem use the <CODE>scrollReady()</CODE> suffix.
 * <P>
 * The default font can be altered with the <CODE>setFont</CODE> suffix and
 * the size of the default font can be altered with the 
 * <CODE>changeSize</CODE> suffix.  Either of these alterations will
 * be taken into consideration when establishing the initial
 * text area's size.
 * <P><FONT SIZE="-1"><B>One Gotcha:</B> Because initial text is
 * used in determining initial size, it is often the best policy
 * not to use <CODE>showText()</CODE> as a suffix. Wait until the window
 * has been created and the size established.   Otherwise you may get
 * a text area that is far too large for the screen.
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
class ZTextlines extends ZObject {
    
//// instance & package ////
    
    private final JTextPane 
        thePane = new JTextPane();
    private final SizableJScrollPane 
        theSPane = new SizableJScrollPane( thePane );

    private int desiredNCols = 0;          // controlled by numColsRows
    private int desiredNRows = 0;          // controlled by numcolsRows
    private Dimension desiredMinSize = null;   // controlled by minSize

    private boolean expandH = false;           // controlled by expandH
    private boolean expandV = false;           // controlled by expandV
  
    private boolean scrollReady = false;   // controlled by scrollReady
    
    private int estimateHeight(int numRows ) {  // numRows >= 0
        thePane.setText("&");
        int h1 = thePane.getPreferredSize().height;
        thePane.setText("&\n&");
        int hDelta = thePane.getPreferredSize().height - h1;
        return h1 + (numRows-1)*hDelta;
    }
    
    private int estimateWidth(int numCols) {  // numCols >= 0
        StringBuffer b = new StringBuffer(numCols);
        for( int i=0; i<numCols; i+=1 ) 
            if( i%3==0 ) b.append('W');
            else         b.append('t');
        thePane.setText(new String(b));
        return thePane.getPreferredSize().width;
    }
    
    private Dimension getNeededSize(String txt) {
        String [] tary = Zio.extractLines(txt);
        int mx = 0;
        for( int i=0; i<tary.length; i+=1 ) {
            thePane.setText(tary[i]);
            int width = thePane.getPreferredSize().width;
            if( mx<width ) mx = width;
        }
        return new Dimension( mx, estimateHeight( tary.length ) );
    }
    
//// public & final ////    
    
    /**
     * Creates an empty <CODE>ZTextlines</CODE> object.
     */
    public ZTextlines() {}
    
    /**
     * Suffix that determines the background 
     * color of the <CODE>ZTextlines</CODE>. 
     * @param c the desired color
     */
    public final ZTextlines background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }
    
    /** Suffix that sets the foreground color.
     * This is the color of the text.
     */
    public final ZTextlines foreground( Color c ) {
        suffixChek();
        desiredForeground = c;
        return this;
    }

    /**
     * Suffix that determines color of the area the
     * user has selected with the mouse.
     * @param c the desired color
     */
    public final ZTextlines selectionBackground( Color c ) {
        suffixChek();
        thePane.setSelectionColor(c);
        return this;
    }
    
    /** Suffix that sets the selection's foreground color.
     * This is the color of text  the user has 
     * selected with the mouse.
     */
    public final ZTextlines selectionForeground( Color c ) {
        suffixChek();
        thePane.setSelectedTextColor(c);
        return this;
    }

    /**
     * Suffix that creates debug output.
     * @param debugId a string to identify this component 
     * in the debug output
     */
    public final ZTextlines debug( String debugId ) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }
    
    /**
     * Suffix which sets the font the
     * label will appear in.  
     * @param f the desired font
     */
     public
    final ZTextlines setFont(Font f) {
        suffixChek();
        thePane.setFont(f);
        return this;
    }

    /**
     * Suffix which alters the
     * point size of the font.
     * @param pointSize the desired point size
     */
    public
    final ZTextlines pointSize(int pointSize) {
        suffixChek();
        setFont(Zio.changePointSize( thePane.getFont(), pointSize ) );
        return this;
    }

    /** 
     * Suffix that sets the minimum size.  This suffix
     * adjusts the amount of screen real estate that the <CODE>ZTextlines</CODE>
     * object will fill.  The actual <CODE>Dimension</CODE> allowed
     * is obtained by taking the largest width and height 
     * found in any of the following: the initial text, this
     * suffix, the <CODE>numRowCols()</CODE> suffix.
     * @param minSize the desired size
     */
    public final ZTextlines minSize( Dimension minSize ) {
        suffixChek();
        chekMinimumD(minSize,"size suffix");
        this.desiredMinSize = minSize;
        return this;
    }
    
    /**
     * Suffix that adjusts the size.  Desired size
     * is set by establishing the approximate number of rows and
     * columns that can be written.  This suffix adjusts
     * amount of screen real estate that the <CODE>ZTextlines</CODE> 
     * object will fill.  The actual <CODE>Dimension</CODE> allowed
     * is obtained by taking the largest width and height
     * found in any of the following: the initial text, this
     * suffix, the <CODE>size()</CODE> suffix.
     * @param numRows the desired number of rows
     * @param numColumns the desired number of columns
     */
    public final ZTextlines numColsRows(int numColumns, int numRows) {
        suffixChek();
        if( numColumns<=0 || numRows<=0 ) 
            Zio.abort(
                 "ZTextlines ("+ debugId + ") numRowsCols suffix "+
                 "requires positive parameters."
            );
        desiredNCols = numColumns;
        desiredNRows = numRows;
        return this;
    }
                                                              
     /**
     * Suffix that enables horizontal stretching.
     * Use this to allow your text area to be streched
     * in a horizontal direction when the user resizes your
     * window.
     */
    public final ZTextlines expandH() {
        suffixChek();
        expandH = true;
        return this;
    }

    /**
     * Suffix that enables horizontal stretching.
     * Use this to allow your text area to be streched
     * in a horizontal direction when the user resizes your
     * window.
     */
    public final ZTextlines expandV() {
        suffixChek();
        expandV = true;
        return this;
    }

    /**
     * Suffix that creates an etched frame around
     * the text area.  Do not use with
     * the <CODE>sunken()</CODE> or <CODE>unframed()</CODE> suffixes.
     */
     public final ZTextlines framed(int margin) {
        suffixChek();
        if( this.margin>=0 || frameType==-1 ) Zio.abort(
            "use only one of sunken(), framed() and unframed()" );
        frameType = 1;
        this.margin = Math.max(0,margin);
        return this;
    }

   /** Suffix that creates the margin used with a frame without
     * creating the frame.
     * This margin overrides any other spacing on the sides
     * of the slice. Do not use with <CODE>framed()</CODE> suffix.
     * @param margin size of margin around the text area
     */
    public final ZTextlines unframed( int margin ) {
        suffixChek();
        if( this.margin>=0 || frameType==-1) Zio.abort(
            "use only one of sunken(), framed() and unframed()" );
        this.margin = Math.max(0,margin);
        return this;
    }

    /**
     * Suffix that gives the text area a sunken look.
     *  Do not use with
     * the <CODE>framed()</CODE> or <CODE>unframed()</CODE> suffixes.
     */
     public final ZTextlines sunken() {
         suffixChek();
         if( this.margin>=0 ) Zio.abort(
            "use only one of sunken(), framed() and unframed()" );
         frameType = -1;
         thePane.setBorder( 
            BorderFactory.createLoweredBevelBorder()
         );
         return this;
     }

     
   /**
    * Suffix that causes scrollbars to appear when 
    * necessary.
    */
    public final ZTextlines scrollReady() {
        suffixChek();
        scrollReady = true;
        return this;
    }

   /**
     * Writes a <CODE>String</CODE> into the text area.
     * @param showMe the <CODE>String</CODE> to write
     */
    public final ZTextlines showText( String showMe ) {
        thePane.setText(showMe);
        return this;
    }

    /**
     * Fetches then substring selected by the user.  This
     * is the string whose colors are affected by 
     * <CODE>selectionForeground()</CODE> and <CODE>selectionBackground()</CODE>.
     * return the substring currently selected by the user.
     */
     public final String getSelection() {
         String retval = thePane.getSelectedText();
         if( retval==null ) retval = "";
         return retval;
     }
    
//// subclass redefinition ////
    
    void debugInfo() {
        Zio.p(
            debugId + "(" + name() + "): setup" +
            "\n  size=" + minD + 
            "\n  maxsize=" + maxD +
            "\n  foregroundColor=" + Zio.colorToStr(desiredForeground)+
            "\n  backgroundColor=" + Zio.colorToStr(desiredBackground) +
            "\n  " + 
            (expandH ? "expands" : "does not expand") + " horizontally"+
            "\n  " +
            (expandV ? "expands" : "does not expand") + " horizontally\n"
        );
    }

    final String name() { return  "ZTextlines"; }
    
    final void setup( 
        Color inheritedForeground, 
        Color inheritedBackground,
        ZObjects all
    ) {
        thePane.setEditable(false);
        String restoreMe = thePane.getText();
        Dimension eSiz = theSPane.swingSize();
        boolean hasInitialSize =
                     eSiz!=null && eSiz.width!=0 && eSiz.height!=0;
        if( !hasInitialSize && desiredNCols==0 && desiredMinSize==null )
            Zio.abort(
                 "ZTextlines ("+ debugId + ") requires some indication"+
                 " of size before window setup, use numColsRows() or " +
                 " size() or showText()."
            );
        if(hasInitialSize) 
            eSiz = getNeededSize( thePane.getText() );
        if( desiredNCols>0 ) {
            Dimension rcSiz =  new Dimension( 
                          estimateWidth(desiredNCols),
                          estimateHeight(desiredNRows)
                     );
            eSiz = (eSiz==null) ? rcSiz : Zio.maxD(eSiz,rcSiz);
        }
        if( desiredMinSize!=null ) {
            eSiz = 
               (eSiz==null) ? 
                   desiredMinSize :  Zio.maxD(desiredMinSize,eSiz);
        }
        thePane.setText(restoreMe);
        if( !scrollReady ) {
            theSPane.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER );
            theSPane.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_NEVER );
        }
        setJCom(theSPane);
        setSize( eSiz );
        setMaxSize( new Dimension( 
             expandH ? Zio.MAX : minD.width,
             expandV ? Zio.MAX : minD.height
        ));
        super.setup(inheritedForeground,inheritedBackground,all);
        thePane.setForeground(Zio.copyC(desiredForeground));
        thePane.setBackground(Zio.copyC(desiredBackground));
    }

//// contained classes ////

    private final class SizableJScrollPane extends JScrollPane {
 
        SizableJScrollPane( JTextPane jtp ) { super(jtp); }
        
        public final Dimension getMinimumSize() { return minD; }                                                     
        public final Dimension getPreferredSize() { return minD; }
        public final Dimension getMaximumSize() { return maxD; }
        
    
        final Dimension swingSize() { return super.getPreferredSize(); }
    
    }

}
