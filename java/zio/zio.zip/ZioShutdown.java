// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

/**
 * Use this class to alter the zio package's shutdown behavior.
 * This class contains two methods:
 * <P>
 * <UL>
 * <LI>  <CODE>cleanupAction()</CODE> called by <CODE>Zio.stop()</CODE>
 * <LI> <CODE>errorAction()</CODE> called by <CODE>Zio.abort()</CODE> and
 * when there is an IOException in the zio package's code.
 * </UL>
 * <P>
 * Make a subclass and override these methods if you want
 * different behavior.  THEN you have to pass
 * an instantiation of your subclass to <CODE>Zio.registerShutdown()</CODE>.
 */
public 
class ZioShutdown {
    
//// for subclass redefinition ////

    /** Defines cleanup for a normal stop with <CODE>Zio.stop()</CODE>.
     * Currently this method does nothing.  See the class
     * documentation.
     */
    protected void cleanupAction() { }
    
    /**
    * Defines error action for <CODE>Zio.abort()</CODE> and any
    * IOExceptions raised in the zio package's code.
    * Currently this action writes a message to the console
    * and does a <CODE>System.exit</CODE>.  See the class documentation.
     * @param message an error message
     * @param e the generating exception or null
     */
    protected void errorAction(String message, Exception e) {
        Zio.show(message);
        System.exit(1);
    }
    
}

