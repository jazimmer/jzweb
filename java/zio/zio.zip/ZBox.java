// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *  Use this class to make colored boxes which are optionally expandable.
 * There is an <CODE>action</CODE> method which is invoked whenver there is 
 * a mouseclick over the box.  Make a subclass and override this
 * method if you want something interesting to happen then.
 * <P>
 * The actual Swing object that this class creates is a <CODE>JPanel</CODE>.
 * Since you have direct access to that object (through the 
 * <CODE>getJPanel()</CODE> method) you can use this class for AWT drawings
 * as well.  In that case you must change either the background or
 * the foreground color as, by default, they will be the same.
 * <P>  Some of your layouts may require you to have both an object and
 * some space expand in the same slice.  With normal use of
 * <CODE>ZRow</CODE> and <CODE>ZCol</CODE> this would be impossible.  With a
 * box that is colored the same as the slice's background color,
 * you can get around that restriction.
 * <P>Do not put other Swing 
 * entities into the panel returned by <CODE>getJPanel()</CODE>.  The
 * <CODE>ZRow</CODE>, <CODE>ZCol</CODE>, and <CODE>ZComponent</CODE> methods
 * are provided so that you can place other Swing
 * objects into your window under a consistent layout 
 * management.
 * @see <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Dimension.html">Dimension
 </A>, <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Color.html">Color</A>
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
class ZBox extends ZObject {

//// instance & package ////
    
    private Dimension desiredSize = null;
    private boolean expandH = false;
    private boolean expandV = false;
    private boolean enableMouseAction = false;

    // class MouseActionListener
    private final class MouseActionListener extends MouseAdapter {

        public void mouseClicked(MouseEvent e) {
            if( !enableMouseAction ) return;
            //if(getJCom().isFocusable()) getJCom().grabFocus();
            if( e.getButton()==MouseEvent.BUTTON1 ) {
                action(true, e.getPoint());
            } else {
                action(false, e.getPoint());
            }
        }

        public void mousePressed(MouseEvent e) {}

        public void mouseReleased(MouseEvent e) {}

    }
    
//// public & final ////    
    
    /**
     * Creates a box
     * By default, the width and length of this box
     * are both one twelfth the height of the
     * screen (measured in pixels) and the color 
     * is the same default color 
     * that is used to write text (usually black).  
     * <P> In Swing or AWT
     * parlance, this implies the default background 
     * color of a box is the same as the default
     * foreground color.
     */
    public ZBox() {
        Dimension d = Zio.getScreenSize();
        desiredSize = new Dimension( d.height/12, d.height/12 );
    }
    
    /**
     * Sets the background 
     * color of the <CODE>ZBox</CODE>. Need not be used
     * as a suffix but when it is used as a suffix
     * the effect is the same as the
     * <CODE>background</CODE> suffix 
     * @param c the desired color
     */
    public final ZBox color( Color c ) {
        if( setupDone() ) {
            getJCom().setBackground(c);
        } else {
            desiredBackground = c;
        }
        return this;
    }
    
    /** Suffix that sets the foreground color.
     * The foreground color is the color of any 
     * AWT generated drawing on the ZBox.
     * @param c the desired foreground color
     */
    public
    final ZBox foreground( Color c ) {
        suffixChek();
        desiredForeground = c;
        return this;
    }

    /** Suffix that sets the background color.
     * The effect is identical to the <CODE>color</CODE> suffix.
     * @param c the desired background color
     */
    public
    final ZBox background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }
    
    /**
     * Suffix that overrides the default size.
     * @param desiredSize the desired size
     */
    public final ZBox size( Dimension desiredSize ) {
        suffixChek();
        chekMinimumD(desiredSize,"size suffix");
        this.desiredSize = desiredSize;
        return this;
    }
    
    /**
     * Suffix that enables horizontal stretching.
     * Use this to allow your box to be streched
     * in a horizontal direction when the user resizes your
     * window.
     */
    public final ZBox expandH() {
        suffixChek();
        expandH = true;
        return this;
    }
    
    /**
     * Suffix that enables vertical stretching.
     * Use this to allow your box to be streched
     * in a vertical direction when the user resizes your
     * window.
     */
    public final ZBox expandV() {
        suffixChek();
        expandV = true;
        return this;
    }
 
    /**
     * Suffix that creates debug output.
     * @param debugId a string to identify this component 
     * in the debug output
     */
    public final ZBox debug( String debugId ) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }
    
    /**
     * Get a reference to the underlying <CODE>JPanel</CODE>.
     * @return the <CODE>JPanel</CODE> controlled by this object
     */
    public
    final JPanel getJPanel() {
        return (JPanel)getJCom();
    }
    
//// subclass redefinition ////
    
    final String name() { return "ZBox"; }
    
    void debugInfo() {
        Zio.p(
            debugId + "(" + name() + "): setup" +
            "\n  size=" + minD + 
            "\n  maxsize=" + maxD +
            "\n  foregroundColor=" + Zio.colorToStr(desiredForeground)+
            "\n  backgroundColor=" + Zio.colorToStr(desiredBackground) +
            "\n  " + (expandH ? "expands" : "does not expand") + " horizontally"+
            (expandV ? "\n  expands" : "\n  does not expand") + " vertically\n"
        );
    }

    final void setup(
        Color inheritedForeground,
        Color inheritedBackground,
        ZObjects all
    ) {
        setJCom(new SizableJPanel());
        setSize( desiredSize );
        if( desiredBackground==Zio.NOCOLOR ) // switcheroo
            desiredBackground = inheritedForeground;
        setMaxSize( new Dimension( 
            expandH ? Zio.MAX : minD.width,
            expandV ? Zio.MAX : minD.height
        ));
        if( enableMouseAction ) 
            getJCom().addMouseListener( new MouseActionListener() );
        super.setup(inheritedForeground,inheritedBackground,all);
    }

    /**
     * Method for causing the <CODE>action()</CODE> method to be
     * executed upon mouse clicks.
     * Has no discernable effect unless the <CODE>action()</CODE>
     * method is overridden in a subclass.
     */
    protected void enableMouseAction() { enableMouseAction = true; }
    
    //// for superclass redefinition ////
    
    /**
     * For execution when user clicks the mouse over
     * the <CODE>ZBox</CODE>.  In this base class the <CODE>action()</CODE>
     * method does nothing and is not invoked. 
     * <P> To cause this method to be invoked whenever
     * the user clicks the mouse, 
     * <OL>
     * <LI> override the method in a subclass, and
     * <LI> in the your subclass's constructor, execute 
     *  <CODE>enableMouseAction()</CODE>
     * </OL>
     * You can also execute suffixes inside this constructor rather
     * than waiting for an object to be created.  (When overriding
     * a <CODE>ZObject</CODE> class, it is usually easier to use suffixes
     * this way.)  
     * <P> The point passed to <CODE>action()</CODE>
     * has the upper lefthand corner of the component as
     * its origin.  The y coordinate is positive in a downward
     * direction.
     * @see 
     * <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Point.html">Point</A>
     * @param isLeftButton true when the clicked button was the left 
     * or "first" button
     * @param point coordinates of the point where the
     * left mouse button was released
     */
    protected void action(boolean isLeftButton, Point point) { }
    
}

