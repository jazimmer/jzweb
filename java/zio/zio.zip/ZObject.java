// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * Base class for everything that goes into a <CODE>ZWindow</CODE>.  
 * Only one method may be useful.
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
abstract class ZObject {

//// for instance & package ////

    final static String DEFAULT_ID = "unamed_object";  
    String debugId = DEFAULT_ID;       // controlled by debug suffixes
    private boolean setupDone = false; // controlled by setup
    boolean atomic = true;
                    // should be false only for ZSlices
                    // using this rather than instanceof so that
                    // ZObject won't need ZSlice to compile
    private JComponent theJCom;        // controlled by setJCom
    Color desiredForeground = Zio.NOCOLOR; 
    Color desiredBackground = Zio.NOCOLOR; 
    Dimension minD = null; 
              // controlled by setSize, makeFrame, resize
    Dimension prefD = null;
              // INVARIANT: when prefD != null, prefD is equivalent to
              //            (or exactly equal to) minD
    Dimension maxD = null; 
              // INVARIANT: when maxD != null its width and
              //            height are either the same as those
              //            of minD or are Zio.MAX
    int margin = -1;  // used to determine margin on all sides
    int frameType = 0;  // currently only one frame type
                        // so this is 0 or 1
    
    private void makeFrame() {  // precon: frameType>0 
        Border etched = BorderFactory.createEtchedBorder();
        Insets incr = etched.getBorderInsets(theJCom);
        if( margin>0 ) {
            MatteBorder mb = 
                new MatteBorder( 
                    new Insets( margin, margin, margin, margin ),
                    desiredBackground
                );
            theJCom.setBorder(
                BorderFactory.createCompoundBorder(etched,mb)
            );
            minD.setSize(
                minD.width + 2*margin + incr.left + incr.right,
                minD.height + 2*margin + incr.top + incr.bottom
            );
        } else {
             theJCom.setBorder( etched );
             minD.setSize(
                minD.width + incr.left + incr.right,
                minD.height + incr.top + incr.bottom
             );
        }
        prefD = minD;
        maxD = Zio.maxD(maxD,prefD);
    }
         
    private void makeMatte() { // precon: frameType==0 && margin > 0
        MatteBorder mb = 
            new MatteBorder( 
                new Insets( margin, margin, margin, margin ),
                desiredBackground
            );
        theJCom.setBorder( mb );
        minD.setSize(
            minD.width + 2*margin,
            minD.height + 2*margin
        );
        prefD = minD;
        maxD = Zio.maxD(maxD,prefD);
    }

    static class ZObjects {
        
        private ZObject [] zary;
        private int n;
        private int c = -1;
        
        ZObjects() { this(8); } 
    
        ZObjects(int initSize) {
            n = 0;
            zary = new ZObject [initSize];
        }
        
        void add( ZObject obj ) {
            if(obj==null) throw new IllegalArgumentException( 
                            "ZObjects.add cannot be given null object");
            if( n == zary.length ) {
                ZObject [] newzary = new ZObject [2*zary.length];
                for(int i=0; i<zary.length; i+=1) newzary[i] = zary[i];
                zary = newzary;
            }
            zary[ n++ ] = obj;
        }
        
        ZObject first() { 
            if( n==0 ) return null;
            c = 0;
            return zary[c++];
        }
        
        ZObject next() {
            if( c==-1 || c>=n ) { c = -1; return null;  }
            return zary[c++];
        }
        
        void downsize( double factor ) {
            ZObject z = first();
            while( z!=null ) {
                if( z.atomic ) {
                    z.prefD = z.minD = Zio.timesD( z.minD, factor );
                    if( z.maxD.width<Zio.MAX ) 
                        z.maxD.width = z.minD.width;
                    if( z.maxD.height<Zio.MAX )
                        z.maxD.height = z.minD.height;
                    if( z.debugId!=DEFAULT_ID ) {
                        Zio.show( "RECALCULATED ..." );
                        z.debugInfo();
                    }
                } else {
                    z.downsize(factor);
                }
                z = next();
            }
        }
        
    }  // end ZObjects class

    void setJCom( JComponent jcom ) {
        if( jcom==null ) internalError(
                "attempt to set null JComponent "
        );
        if( atomic && theJCom!=null) internalError(
                " attempt to reset JComponent"
        );
        theJCom = jcom;
    }
     
    void setSize( Dimension size ) {
        if( setupDone() && atomic ) internalError(
            "size being set too many times"
        );
        minD = prefD = Zio.copyD(size);
        maxD = Zio.copyD(size);
    }
   
    void setMaxSize(Dimension size) {
        if( setupDone() && atomic ) 
            internalError("max size set after setup");
        if( theJCom==null ) 
            internalError("max size set before initializeObject");
        if( (size.width!=minD.width && size.width!=Zio.MAX) ||
            (size.height!=minD.height && size.height!=Zio.MAX) 
        ) internalError("max size invariant violated");
        maxD = Zio.copyD(size);
    }

    void resize( Dimension size, Dimension maxSiz ) {
        if( (size.width!=maxSiz.width && maxSiz.width!=Zio.MAX) ||
            (size.height!=maxSiz.height && maxSiz.height!=Zio.MAX) 
        ) internalError("max size invariant violated");
        maxD =Zio.copyD(maxSiz);
        resize( size );
    }
    
    void fixColor(
        Color inheritedForeground, Color inheritedBackground
    ) {
        if( setupDone() && atomic ) internalError(
            "attempt to fix colors twice"
        );
        if( inheritedForeground==null || inheritedBackground==null )
            internalError("attempt to fix null colors");
        if( desiredForeground==Zio.NOCOLOR ) 
            desiredForeground = inheritedForeground;                                            
        if( desiredBackground==Zio.NOCOLOR ) 
            desiredBackground = inheritedBackground;
    }

    boolean setupDone() { return setupDone; }
    
    
    JComponent getJCom() {
        if( theJCom == null ) 
            internalError("attempt to get nonexistent JComponent;" +
                   " probably getJCom used before initializeObjects"  );
        return theJCom; 
    }
    
    JPanel getJPanel() { return (JPanel)theJCom; }
    
    // chek...
    final static String NOTNULL =
        " constructors and methods cannot accept null arguments";

    final void chekForNulls(Object [] obj) {
        for( int i=0; i<obj.length; i+=1 ) {
            if( obj[i]==null ) throw new IllegalArgumentException(
                name() + 
                " unexpected null argument (internal error)"
            );
        }
    }
   
    final void chekForNull( Object obj ) {
        if( obj==null ) throw new IllegalArgumentException(
            name() + 
            " unexpected null argument (internal error)"
        );
    }
   
    final void chekMinimumD(Dimension d, String methodName ) {
        if( d==null || d.width<0 || d.height<=0  )
            throw new IllegalArgumentException(
                name() + ": " + methodName + 
                "needs a positive dimension (internal error)"
            );
        if( d.width==Zio.MAX || d.height==Zio.MAX ) 
            throw new IllegalArgumentException(
                name() + ": " + methodName +
                "'s minimum dimension cannot have a MAX value (internal error)"
            );
    }

 
    final void internalError(String reason) {
        throw new IllegalStateException(
            name() + " internal  error: " + reason
        );
    }
   
    final void windowIsNeeded(String methodName) {
        if( !setupDone() ) throw new IllegalStateException(
            name() + "." + methodName +
            " cannot be used until containing ZWindow is created" 
        );
    }
    
    final void suffixChek() {
        if( setupDone() ) throw new IllegalStateException(
            name() +  
            " suffix must be executed before object is put in a ZWindow"
        );
    }
    
    
//// final & public ////

    /**
     * Obtains the minimum/preferred size.
     * Only works after a window has been
     * created.
     * @return the minimum/preferred size
     */
     public Dimension getSize() {
         windowIsNeeded("getSize");
         return minD;
     }
     
//// for subclass definition ////

    abstract String name();
    
    void debugInfo() {
        Zio.p(debugId+ " (" + name() + "): setup" +
              "\n  size=" +minD+ 
              "\n  maxsize=" +maxD+ 
              "\n  foregroundColor=" + Zio.colorToStr(desiredForeground)+
              "\n  backgroundColor=" + Zio.colorToStr(desiredBackground) +
              "\n"
        );
    }
    
    void resize( Dimension size ) {  // only redefined in JComponent
        minD = prefD = Zio.copyD(size);
        maxD = Zio.maxD(size,maxD);
    }

    void downsize( double factor ) {
        Zio.abort(
           "ZObject.downsize not meant to be executed without change"
        );
    }
    
    void setup( 
        Color inheritedForeground,
        Color inheritedBackground,
        ZObjects all 
    ) {  

        // about overriding methods:
        //   1) must call this base version someplace
        //   2) must have minD,prefD, and maxD correct based
        //      on all info base within the ZObject of any
        //      of its component objects
        //   3) if containing object wants a different size it can
        //      enlarge this object but not any component objects
        
        if( setupDone() && atomic ) 
            throw new IllegalStateException(
                      "Have you attempted to put a ZObject in two " +
                      " windows or two places in one window?  That is " +
                      " the most common cause of this error: " +
                      name() + " - " + debugId 
            );
        if( theJCom==null ) internalError("no JComponent at setup");
        if( minD==null ) internalError("no size at setup");
        if( atomic ) fixColor(inheritedForeground, inheritedBackground);
        theJCom.setForeground(Zio.copyC(desiredForeground));
        theJCom.setBackground(Zio.copyC(desiredBackground));
        if( frameType>0 ) makeFrame();
        else if ( margin>0 ) makeMatte();
        if( debugId!=DEFAULT_ID ) debugInfo();
        if( !setupDone() ) all.add(this);
        setupDone = true;
    }

    // class SizableJPanel -- used sometimes
    class SizableJPanel extends JPanel {
        public final Dimension getMinimumSize() {  return minD; }
        public final Dimension getPreferredSize() { return minD; }
        public final Dimension getMaximumSize() { return maxD; }
    }

}
