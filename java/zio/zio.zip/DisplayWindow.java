// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import java.awt.*;
import java.awt.image.*;


/**
 * This displays some text, an image, or both.
 * This class was made for teaching purposes.  It is meant to be
 * used with the <CODE>DialogWindow</CODE> class.  As an introduction,
 * here is an example which does not involve <CODE>DialogWindow</CODE>.
 * <P><PRE>
 * DisplayWindow = new DisplayWindow(
 *      "Window Title",
 *      InOut.readImage("pictureFilename.jpg"),
 *      "Picture Caption\nmultiple lines ok"
 * );
 * </PRE><P>
 * This creates an unchangeable window titled "Window Title".  The
 * window shows an image taken from the file named 
 * "pictureFilename.jpg" and with a multiline caption as indicated.  
 * A runtime error is generated if this window will not fit on
 * the screen.
 * Although unchangeable, the window can be temporarily removed
 * from the screen.
 * @see <A HREF="../../zioDialog.html">zioDialog</A>
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public class DisplayWindow { 

//// instance & package ////
    
    private ZWindow theWindow;
    private ZTextlines text = null;    
    private ZPicture picture = null;
    
    private void makeWindow( String titl ) {
        ZObject windowContents;
        if( text!=null && picture!=null ) {
            windowContents = 
                new ZCol(
                    new ZRow( picture, text ).space(15) 
                ).space(15);
        } else if( picture!=null ) {
            windowContents = picture;
        } else {
            windowContents = text;
        }
        theWindow = new ZWindow( titl, windowContents, false );
        Dimension dw = windowContents.getSize();
        Dimension ds = Zio.getLargestZObject();
        if( dw.width>ds.width || dw.height>ds.height )
            Zio.abort(
                "this DisplayWindow is too large for this screen"
            );
        theWindow.show();
    }

//// public & final ////
    
    /**
     * Creates a display window with both image and
     * text.
     * @param titl the title of the window
     * @param picture the image to be displayed or null
     * @param text the text to be displayed or null
     */
    public DisplayWindow( 
        String titl,
        BufferedImage picture, 
        String text
    ) {
        if( picture==null && text==null ) 
            Zio.abort(
                "the picture and text parameters cannot both be null"
            );
        if( picture!=null ) 
            this.picture = new ZPicture().showImage(picture);
        if( text!=null )
            this.text = new ZTextlines().showText(text);
        makeWindow( titl );
    }
    
    /** Creates a display window with text only.
     * @param titl the title of the window
     * @param text the text to be displayed or null
     */
    public DisplayWindow( String titl, String text ) {
        this( titl, null, text );
    }
    
    /** 
     * Creates a display window with only an image.
     * @param titl the title of the window
     * @param picture the image to be displayed or null
     */
    public DisplayWindow( String titl, BufferedImage picture ) {
        this(titl, picture, null );
    }

    /**
     * Removes a window from the screen without getting rid
     * of it.  Will not wokr if the window is the only
     * unhidden window the program has.  This ensures that
     * users always have a way to shut down programs.
     */
    public final void hide() { theWindow.hide(); }
    
    /**
     * Redisplays a hidden window.  Has no effect if 
     * the window is already visible.
     */
    public final void show() { theWindow.show(); }
    
    /**
     * Closes the window which means it is gone forever.
     * If this is the only unhidden window, the program
     * stops.
     */
    public final void closeWindow() { theWindow.closeWindow(); }
        
}
