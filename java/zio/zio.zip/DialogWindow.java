// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
package zio;

import java.awt.*;


/** 
 * Provides a window that can be used for a continuing dialog with 
 * the user.  This class was created for teaching purposes and is
 * meant to be used with the <CODE>DisplayWindow</CODE> class.
 * <P> Responding to user input requires a different style of 
 * programming than the question and answer stye that was prevalent
 * decades ago in command window.  The user decides when and where
 * to enter data.  The effect of entering data must be to start
 * some part of the program executing.  In this case, that part
 * of the program is the <CODE>processInput()</CODE> method.  There is
 * one parameter to <CODE>processInput()</CODE> and that is the <CODE>String</CODE>
 * the user has just entered.
 * <P> The <CODE>processInput</CODE> in this class does nothing!  To write 
 * a useful program you have to make a subclass of <CODE>DialogWindow</CODE> 
 * (by extending it) and write your own version of <CODE>processInput()</CODE>.
 * Here is a simple example that does not involve <CODE>DisplayWindow</CODE>.
 * <P><PRE>
 * class Echo extends DialogWindow {
 *     public My Dialog() { 
 *        super("Echo","I will echo your input.");
 *     }
 *     public void processInput( String userin ) {
 *        displayString(userin);
 *     }
 * }
 * </PRE><P>
 * Now this 
 * <P><PRE>
 *   new Echo();
 * </PRE><P>
 * will create a window that echos user input.
 * <Fl> Why is <CODE>processInput</CODE> <CODE>public</CODE> rather than <CODE>protected</CODE>?
 * Only so a teacher can avoid talking about <CODE>protected</CODE> a little
 * longer. </Fl>
 * @see <A HREF="../../zioDialog.html">zio Dialog</A> 
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public class DialogWindow { 

//// instance & package ////
    
    private ZTextlines text;    
    private ZKeyboard input; 
    private ZWindow thisWindow; 
    
    private class ProcessInput extends ZKeyboard { 
        
        protected final void action(String s) { 
            input.setText("");
            processInput(s);
        }
    
    }

//// public & final ////
    
    /**
     * Create a dialog window with title and prompt.
     * The title will be put in the window's title bar and the
     * prompt is the initial message to the user.  It will be put
     * in the same place as all other messages to the user.
     */
     public DialogWindow(String title, String initialMessage ) {
        // i don't know why the text and keyboard areas do not
        // make the same estimated widths
        input = new ProcessInput()
                .numCols(40)
                .pointSize(11);
        text = new ZTextlines()
                    .numColsRows(42,1)
                    .pointSize(11)
                    .showText(initialMessage);
        thisWindow = new ZWindow( 
            title,                   
            new ZRow(
                new ZCol( 
                    new ZRow(text).atLeft().space(0),
                    new ZRow(input).atLeft().space(0)
                )
            )
        );
    }
   
    /**
    *  Display a <CODE>String</CODE>  message in the dialog window.
    * @param s the <CODE>String</CODE> to be displayed
     */
     public final void displayString(String s) { 
        text.showText(s); 
    }
 
    /**
     * Closes the window which means it is gone forever.
     * Will not work if no other window is visible.  Use
     * Zio.stop() to stop a program.
     */
    public final void closeWindow() { thisWindow.closeWindow(); }
    
    
//// for subclass redefinition ///    
    
    /**
     * This method is invoked (but not by you) every time
     * the user enters a <CODE>String</CODE>.  Create a subclass
     * and override this method to determine what response
     * will be made to the user.
     * <Fl> This method is <CODE>public</CODE> for no reason other 
     * than to allow students to use it before they understand
     * about +/C{protected} methods. </Fl>
     * @param userin count on this being the (possibly empty) string
     * the user has just input
     */
     public void processInput(String userin) { };
    
}
