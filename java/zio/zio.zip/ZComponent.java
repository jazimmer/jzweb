// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax.swing.*;
import java.awt.*;

/**
 * Converts <CODE>JComponent</CODE>s to <CODE>ZObject</CODE>s.
 * If you want to use a Swing object that is not 
 * (yet) available in these
 * classes, you can still use it by wrapping a
 * <CODE>ZComponent</CODE> object around it.  
 */
 public
 class ZComponent extends ZObject {
    
//// instance & package ////
    
    private JComponent component;
    private Dimension desiredSize = null;
    private boolean expandV = false;
    private boolean expandH = false;
    
//// public & final ////
    
    /**
     * Creates a ZObject corresponding to a <CODE>JComponent</CODE>.
     * Do NOT use this for a <CODE>JComponent</CODE> obtained with
     * with <CODE>getContentPane</CODE> (or any other Swing method
     * that gives you a <CODE>Component</CODE> which belongs to
     * another <CODE>Component</CODE>).
     * @param c the <CODE>JComponent</CODE> to be brought into the zio system
     */
     public ZComponent(JComponent c) {
        chekForNull(c);
        component = c;
    }
    
    /**
     * Suffix that creates debug output.
     * @param debugId a string to identify this component
     * in the debug output
     */
    public final ZComponent debug( String debugId ) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }

    /**
     * Suffix that overrides Swing's notion of what the 
     * <CODE>JComponent</CODE>'s minimum/preferred should be.  It is 
     * very common
     * for this suffix to be needed as Swing often does not
     * set a minimum size.
     * @param desiredSize the desired size
     */
     public final ZComponent size( Dimension desiredSize ) {
        suffixChek();
        this.desiredSize = desiredSize;
        return this;
    }
    
     /**
      * Suffix that enables the <CODE>JComponent</CODE> to be stretched
      * in the vertical direction.
      */
    public final ZComponent expandV() {
        suffixChek();
        expandV = true;
        return this;
    }
    
    /**
     * Suffix that enables the <CODE>JComponent</CODE> to be stretched
     * in the horizontal direction.
     */
    public final ZComponent expandH() {
        suffixChek();
        expandH = true;
        return this;
    }
    
    /**
     * Suffix that determines the foreground color of the 
     * <CODE>JComponent</CODE> area.
     * @param c the desired foreground color
     */
    public final ZComponent foreground( Color c ) {
        suffixChek();
        desiredForeground = c;
        return this;
    }
    
    /**
     * Suffix that determines the background color of the 
     * <CODE>JComponent</CODE>.
     * @param c the desired background color
     */
    public final ZComponent background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }

    /** Suffix that creates an etched frame around the <CODE>ZComponent</CODE>.
     *  Do not use with <CODE>unframed()</CODE> suffix.
     * @param margin size of margin between <CODE>ZComponent</CODE> and frame
     */
    public ZComponent framed( int margin ) {
        suffixChek();
        if( this.margin>=0 ) Zio.abort(
            "use only one of framed() and unframed()" );
        frameType = 1;
        this.margin = Math.max(0,margin);
        return this;
    }

   /** Suffix that creates the margin used with a frame without
     * creating the frame.
     * Do not use with <CODE>framed()</CODE> suffix.
     * @param margin size of margin around the <CODE>ZComponent</CODE>
     */
    public ZComponent unframed( int margin ) {
        suffixChek();
        if( this.margin>=0 ) Zio.abort(
            "use only one of framed() and unframed()" );
        this.margin = Math.max(0,margin);
        return this;
    }

    /**
     * Method for obtaining the <CODE>JComponent</CODE>.
     * @return the <CODE>JComponent</CODE> this <CODE>ZComponent</CODE> is associated with
     */
    public JComponent getJComponent() { return component; }
    
   
//// subclass redefinition ////
    
    void debugInfo() {
        Zio.p(
            debugId + ": setup" +
            "\n  size=" + minD + "\n  maxsize=" + maxD +
            "\n  foregroundColor=" + Zio.colorToStr(desiredForeground)+
            "\n  backgroundColor=" + Zio.colorToStr(desiredBackground) +
            "\n  " + (expandH ? "expands" : "does not expand") + " horizontally"+
            (expandV ? "\n  expands" : "\n  does not expand") + " vertically\n"
        );
    }

    String name() { return "ZComponent"; }
    
    void setup(
        Color inheritedForeground,
        Color inheritedBackground,
        ZObjects all
    ) {
        if( setupDone() ) {
            component.setMinimumSize(Zio.copyD(minD));
            component.setPreferredSize(Zio.copyD(prefD));
            component.setMaximumSize(Zio.copyD(maxD));
            super.setup(inheritedForeground,inheritedBackground,all);
            return;
        }
        Dimension swingSize = component.getPreferredSize();
        if( debugId!=DEFAULT_ID ) Zio.p( 
            "ZComponent: Swing's size for " + debugId +
            " is " + swingSize + "\n"
        );
        if( desiredSize==null ) desiredSize = swingSize;
        if( desiredSize.width<=0 || desiredSize.height<=0 ) 
            Zio.abort(
                 "ZComponent (" + name()+ "): setup " +
               "nonpositive size parameter found; use size(...) suffix"
            );
        setJCom( new SizableJPanel() );
        setSize(desiredSize);
        setMaxSize( new Dimension( 
            expandH ? Zio.MAX : minD.width,
            expandV ? Zio.MAX : minD.height
        ));
        getJCom().setLayout( new BoxLayout( getJCom(), BoxLayout.X_AXIS ));
        getJCom().add(component);
        component.setMinimumSize(Zio.copyD(minD));
        component.setPreferredSize(Zio.copyD(prefD));
        component.setMaximumSize(Zio.copyD(maxD));
        super.setup(inheritedForeground,inheritedBackground,all);
    }
    
    void resize( Dimension size ) {
        super.resize(size);
        component.setMinimumSize(Zio.copyD(minD));
        component.setPreferredSize(Zio.copyD(minD));
        component.setMaximumSize(Zio.copyD(maxD));
    }

}
            