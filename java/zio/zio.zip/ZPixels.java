// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import java.awt.*;
import javax.swing.*;

/**
 * This, AS YET UNIMPLEMENTED, class will define an area
 * of the screen where you can plot colored points.
 */
public 
class ZPixels extends ZObject {
    
//// instance & package ////
 
    private boolean enableMouseAction = false;
    private Dimension desiredSize = null;
    
//// public & final //// 

    public ZPixels() { }
    
    /**
     * Suffix that overrides the default size.
     * @param desiredSize the desired size
     */
    public final ZPixels size( Dimension desiredSize ) {
        suffixChek();
        chekMinimumD(desiredSize,"size suffix");
        this.desiredSize = desiredSize;
        return this;
    }
    
    /**
     * Sets the background 
     * color of the <CODE>ZPixels</CODE>. Need not be used
     * as a suffix but when it is used as a suffix
     * the effect is the same as the
     * <CODE>background</CODE> suffix 
     * @param c the desired color
     */
    public final ZPixels color( Color c ) {
        if( setupDone() ) {
            getJCom().setBackground(c);
        } else {
            desiredBackground = c;
        }
        return this;
    }
    
    /** Suffix that sets the background color.
     * The effect is identical to the <CODE>color</CODE> method.
     * @param c the desired background color
     */
    public final ZPixels background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }
    
    public final void plot( Color color, Point p ) { }
    
    public final void clear() { }
    
    public final void draw() { }

        /**
     * Method for causing the <CODE>action()</CODE> method to be
     * executed upon mouse clicks.
     * Has no discernable effect unless the <CODE>action()</CODE>
     * method is overridden in a subclass.
     */
    protected void enableMouseAction() { enableMouseAction = true; }
    
//// superclass redefinitioin ////

    String name() { return "ZPixels"; }
    
//// for subclass redefinition ////
    
    /**
     * For execution when user clicks the mouse over
     * the <CODE>ZPixels</CODE>.  In this base class the <CODE>action()</CODE>
     * method does nothing and is not invoked. 
     * <P> To cause this method to be invoked whenever
     * the user clicks the mouse, 
     * <OL>
     * <LI> override the method in a subclass, and
     * <LI> in the your subclass's constructor, execute 
     *  <CODE>enableMouseAction()</CODE>
     * </OL>
     * You can also execute suffixes inside this constructor rather
     * than waiting for an object to be created.  (When overriding
     * a <CODE>ZObject</CODE> class, it is usually easier to use suffixes
     * this way.)  
     * <P> The point passed to <CODE>action()</CODE>
     * has the upper lefthand corner of the component as
     * its origin.  The y coordinate is positive in a downward
     * direction.
     * @see 
     * <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Point.html">Point</A>
     * @param isLeftButton true when the clicked button was the left 
     * or "first" button
     * @param point coordinates of the point where the
     * left mouse button was released
     */
    protected void action(boolean isLeftButton, Point point) { }

}
