// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax.swing.*;
import java.awt.*;

/**
 * A <CODE>ZRow</CODE> is a horizontal slice of a part of a window.
 * A <CODE>ZRow</CODE> is almost identical to a <CODE>ZCol</CODE>. One can 
 * be obtained
 * from the other by transposing the vertical and horizontal
 * directions.  Both are <CODE>ZObject</CODE>s.
 * A <CODE>ZRow</CODE> will stretch in a horizontal direction
 * when the user expands a window.  If none of the <CODE>ZObject</CODE>s
 * in a column expands horizontally, the expansion will happen in the
 * spaces around the <CODE>ZObject</CODE>s; otherwise it happens in those
 * <CODE>ZObject</CODE>s.  (Those which can expand horizontally.)
 * If any nonexpanding component <CODE>ZObject</CODE> is too short for 
 * the others, it will be centered vertically within the column
 * It you don't like this, you can get position that <CODE>ZObject</CODE>
 *  upwards or downwards by putting a <CODE>ZCol</CODE> around it.
 * and using <CODE>atTop()</CODE> or <CODE>atBottom()</CODE>.
 * <P>By default, <CODE>ZRow</CODE> will not expand vertically even
 * if  component object  is capable of vertical expansion.
 * Think of this default state as "half locked". Horizontal
 * expansion <I>will</I> happen even if none of the component
 * <CODE>ZObject</CODE>s expands horizontally.  Vertical expansion
 * will <I>not</I> happen even if some of the component objects
 * expand vertically.  From
 * this half-locked, state you can use the <CODE>unlock()</CODE> suffix
 * to unlock expansion vertically or the <CODE>lock()</CODE> suffix to
 * lock expansion horizontally.  The <CODE>lock</CODE> suffix overrides
 * the unlock suffix.
 * @see <A HREF="../../slices.html" TARGET="_top">about slices</A>
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
class ZRow extends ZSlice {
     
//// private & instance ////

    private int space = -1;

//// public & final ////
    
    /**
      * Create a <CODE>ZRow</CODE> with multiple objects given in an array.
      * The objects of <CODE>ZRow</CODE> will appear from left to right
      * in the order
      * <CODE>gs[0]</CODE>, <CODE>gs[1]</CODE>, ... .
      * @param gs an array of those <CODE>ZObjects</CODE> which will appear
      * in the row
      */
    public ZRow( ZObject [] gs ) {
        this.gs = gs;
    }
    
    /**
     * Create a <CODE>ZRow</CODE> with a single <CODE>ZObject</CODE>.
     * @param gu the object to appear in the row
     */
    public ZRow( ZObject gu ) {
        ZObject [] gs = { gu };
        this.gs = gs;
    }

    /**
     * Create a <CODE>ZRow</CODE> with two <CODE>ZObject</CODE>s.
     * @param gu1 the leftmost object to appear in the row
     * @param gu2 the rightmost object to appear in the row
     */
    public ZRow( ZObject gu1, ZObject gu2 ) {
        ZObject [] gs = { gu1, gu2 };
        this.gs = gs;
    }

    /**
     * Create a <CODE>ZRow</CODE> with three <CODE>ZObject</CODE>s.
     * @param gu1 the leftmost object to appear in the row
     * @param gu2 the middle object to appear in the row
     * @param gu3 the rightmost object to appear in the row
     */
    public ZRow( ZObject gu1, ZObject gu2, ZObject gu3 ) {
        ZObject [] gs = { gu1, gu2, gu3 };
        this.gs = gs;
    }

    /**
     * Create a <CODE>ZRow</CODE> with four <CODE>ZObject</CODE>s.
     * @param gu1 the leftmost object to appear in the row
     * @param gu2 the left middle object to appear in the row
     * @param gu3 the right middle object to appear in the row
     * @param gu4 the rightmost object to appear in the row
     */
    public ZRow( ZObject gu1, ZObject gu2, ZObject gu3, ZObject gu4 ) {
        ZObject [] gs = { gu1, gu2, gu3, gu4 };
        this.gs = gs;
    }

    /**
     * Suffix that creates debug output.
     */
    public final ZRow debug( String debugId ) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }
    
    /** Suffix that creates an etched frame around the <CODE>ZRow</CODE>.
     * This margin overrides any other spacing on the sides
     * of the slice.  Do not use with <CODE>unframed()</CODE> suffix.
     * @param margin size of margin between the slice and the frame
     */
    public ZRow framed( int margin ) {
        suffixChek();
        if( this.margin>=0 ) Zio.abort(
            "use only one of framed() and unframed()" );
        frameType = 1;
        this.margin = Math.max(0,margin);
        return this;
    }

   /** Suffix that creates the margin used with a frame without
     * creating the frame.
     * This margin overrides any other spacing on the sides
     * of the slice. Do not use with <CODE>framed()</CODE> suffix.
     * @param margin size of margin around the slice
     */
    public ZRow unframed( int margin ) {
        suffixChek();
        if( this.margin>=0 ) Zio.abort(
            "use only one of framed() and unframed()" );
        this.margin = Math.max(0,margin);
        return this;
    }

    /**
    * Suffix that forces leftmost component <CODE>ZObject</CODE> to appear 
     * at the left of the row without any intervening space.
     */
    public final ZRow atLeft() { 
        suffixChek();
        spaceAtFirst = false;
        return this; 
    }
    
    /**
    * Suffix that forces rightmost component <CODE>ZObject</CODE> to
    * appear at the right of the row without any
    * intervening space.
    */
    public final ZRow atRight() {
        suffixChek();
        spaceAtLast = false;
        return this; 
    }

    /**
     * Suffix that sets minimum spacing. 
     * This suffix sets a minimum number of pixels for 
     * the width of a space. If not present, this
     * minimum number is calculated with a complex
     * formula.<P>
     * This minimum always applies to space between
     * component <CODE>ZObject</CODE>s.  It applies to
     * space at left and right only if no <CODE>framed()</CODE>,
     * <CODE>unframed()</CODE>, <CODE>atLeft()</CODE>, or <CODE>atRight()</CODE> suffix has been
     * used.
     */
    public final ZRow space(int space) {
        suffixChek();
        this.space = Math.max(0,space);
        return this;
    }
    
    /** This suffix causes all component <CODE>ZObject</CODE>s to be
     * the same size.  No component object can be a slice. 
     * The calculated size will be the smallest that
     * can accommodate the minimum size of all objects.
     * Causes <CODE>expandH()</CODE> and <CODE>expandV()</CODE> to be ignored.
     */
    public final ZRow uniform() {
         suffixChek();
         uniform = true;
         return this;
    }
     
    /**
     * Suffix that permits row to expand vertically.
     * There is no spacing or padding to make vertical
     * expansion work so it won't happen unless one of
     * the contained <CODE>ZObject</CODE>s already expands vertically.
     */
    public final ZRow unlock() {
        suffixChek();
        unlocked = true;
        return this;
    }
    
    /**
     * Causes row to be unexpandable in any
     * direction.   Causes the <CODE>unlock()</CODE> 
     * suffix to be ignored.
     */
    public final ZRow lock() {
        locked = true;
        return this;
    }
     
    /**
     * Suffix that determines the background 
     * color of the row.  The background
     * color will be seen in the spaces
     * and will be inherited by the contained
     * <CODE>ZObjects</CODE>.
     * @param c the desired color
     */
    public final ZRow background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }
    
    /** Suffix that sets the foreground color of
     * the row.  The foreground color will be
     * inherited by the contained <CODE>ZObjects</CODE>.
     */
    public
    final ZRow foreground( Color c ) {
        suffixChek();
        desiredForeground = c;
        return this;
    }
    
    /** Suffix that creates a grid, or two dimensional
    * array, of <CODE>ZObject</CODE>s.  <CODE>ZObject</CODE>s in any one
    * row are forced to have the same height and <CODE>ZObject</CODE>s
    * in any one column are forced to have the same width.
    * <P> To make the grid, you must populate this <CODE>ZRow</CODE>
    * only with <CODE>ZCol</CODE>s and each column must have the
    * same number of <CODE>ZObject</CODE>s.
    * <P> The only suffixes that work with <CODE>grid()</CODE> are
    * <CODE>foreground()</CODE>, <CODE>background()</CODE>, <CODE>space()</CODE>, 
    * <CODE>framed()</CODE>, <CODE>unframed()</CODE> and <CODE>debug()</CODE>.
    * The only suffix that will work on any the <CODE>ZCol</CODE>s that
    * define the columns of this grid is <CODE>debug()</CODE>.  Suffixes 
    * work as normal on the <CODE>ZObject</CODE>s in the grid.
    * <P> NOT YET IMPLEMENTED.
    */
    public ZRow grid() { return this; }
    
//// superclass redefinition ////

    String name() { return "ZRow"; }
    
    final void piecesAndSizes(ZObjects all) {
        if( !setupDone() ) {
            // SETUP COMPONENTS
            int height = 0;              // becomes max of minD.heights
            int width = 0;               // becomes max of minD.widths
            for( int i=0; i<gs.length; i+=1 ) {
                gs[i].setup(desiredForeground,desiredBackground,all);
                Dimension d = gs[i].minD;
                width = Math.max( width, d.width );
                height = Math.max( height, d.height );
            }
            if( uniform ) {
                Dimension uniD = new Dimension ( width, height );
                for( int i=0; i<gs.length; i+=1 ) {
                    if( !gs[i].atomic ) 
                        Zio.abort(
                           "uniform slices cannot contain slice"
                        );
                    gs[i].resize(uniD,uniD);
                }
            }
    
            // DETERMINE values for parameters
            int maxWidth = 0;            // becomes max of maxD.widths
            int maxHeight = 0;           // becomes max of maxD.heights
            int totalWidth = 0;          // becomes total of minD.widths 
            for( int i=0; i<gs.length; i+=1 ) {
                totalWidth += gs[i].minD.width;
                maxWidth = Math.max( maxWidth, gs[i].maxD.width );
                maxHeight = Math.max( maxHeight, gs[i].maxD.height );
            }
            int spaceWidthMn = 
                (space>=0) ?
                    space : 
                    Math.min( 
                        Zio.getScreenSize().height/4,
                        Math.max(4, (int)(totalWidth/(4.0*gs.length)))
                    );
            if( margin >= 0 ) {  spaceAtFirst = spaceAtLast = false;  }
            if(locked) unlocked = false;
            totalWidth += (gs.length-1)*spaceWidthMn;
            if( spaceAtFirst ) totalWidth += spaceWidthMn;
            if( spaceAtLast ) totalWidth += spaceWidthMn;
            sliceMn.setSize( totalWidth, height );
            spaceMn.setSize( spaceWidthMn, height );
            boolean spacesExpand = maxWidth!=Zio.MAX;
            boolean verticalExpansionWanted = maxHeight==Zio.MAX;
            sliceMaxDelta = new Dimension(
                (!locked ? Zio.MAX : 0), 
                (unlocked && verticalExpansionWanted ? Zio.MAX : 0)
            );
            spaceMaxDelta = new Dimension(
                 (spacesExpand && !locked ? Zio.MAX : 0),
                 (unlocked && verticalExpansionWanted ? Zio.MAX : 0)  
            );
        }  // end if( !setupDone() )

        aboutComponents = 
            "ZRow has " + gs.length + " objects with minimum space " +
            spaceMn.width;
        
        // CREATE
        setJCom( new SizableJPanel() );
        setSize( sliceMn );
        setMaxSize(Zio.maxD( sliceMaxDelta, sliceMn ));
        getJCom().setLayout( 
            new BoxLayout( getJCom(), BoxLayout.X_AXIS ) 
        );
    }
    
 }
    
 
// seting a vertical alignment was tried but it distorted
// the aspect rations;  the same effect without the distortion
// is obtainable by putting a row in a column
   
