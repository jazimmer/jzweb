// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import java.awt.*;
import javax.swing.*;

/**
 * A window of this kind contains a white, fixed-size canvas on which
 * colored points can be plotted.
 *
 * AS YET UNIMPLEMENTED
 */
public class GraphingWindow {

//// instance & package ////
    
    private ZWindow win = null;
    
//// public & final ////

    public GraphingWindow( String title, Dimension size ) { }
    
    public final boolean plot( Color c, int x, int y) {return true;}

    public final void clear() { };
    
    public final boolean prePlot( Color c, int x, int y) {return true;}
    
    public final void drawPrePlotted() { };
    
}

