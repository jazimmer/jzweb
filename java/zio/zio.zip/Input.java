// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import java.io.*;
import java.util.*;

/** 
 * Provides for text input from files
 * <Fl> command windows, sockets, character arrays, Strings 
 * and <CODE>File</CODE> objects</Fl>.
  *<P>Simple Examples<P><PRE>
  * // This example reads 10 ints from the keyboard.  Ints may be
  * // entered on one or more lines.  Ints on the same line must be
  * // separated by spaces.
  *     Input ink = new Input();  // input from keyboard
  *     int [] ary = new int [10];
  *     for(int i=1; i<=10; i+=1) {
  *        ary[i] = ink.findAndReadInt();
  *     }
  * // next example copies a file, line by line from "infile.txt" to 
  * // "outfile.txt" using the Output class with the Input class
  *     Input in = new Input("infile.txt");
  *     Output out = new Output("outfile.txt");
  *     for(;;) {
  *         String line = in.readLine();
  *         if( in.eof() ) break;
  *         out.writeString(line); out.writeEndOfLine();
  *     }
  *     in.close(); out.close();
  *</PRE><P>
  * <Fl>Input operates in three modes: char, token, and line.  In char mode, 
  * end of line chars are read.  In token mode, white space including
  * end of line chars are skipped.  The first example above is an example
  * of token mode.  (There is a maximum token size which can be overridden
  * with a constructor.)  In line mode, end of line chars are thrown away.
  * The second example above is an example of line mode.  You can switch
  * between modes at will but when switching to line mode, the rest of the
  * current input line will be thrown away.  The <CODE>eof()</CODE> method 
  * works the same way in all modes: you try to read something first and 
  * then ask whether an end of file was encountered.
  * <P>
  * Error handling can be overridden by subclassing the <CODE>Zio</CODE> class.
  * To change token separators, create a subclass and override the 
  * <CODE>notATokenChar()</CODE> method.  To change maximum token size, use the
  * appropriate constructor.
  * <P> Consider using the <CODE>File</CODE> class in conjunction with this
  * class; that way offers greater flexibility over the direct use of file names.</Fl>
  * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
  * @version Jul 22, 2005
  */
public class Input {

    private char [] token;
    private int nextChar;  // the next char in file, if token mode
    private boolean eof;   // if token mode, nextChar==-1 iff eof
    private BufferedReader in;
    private int mode;   // can be LINE, CHAR, or TOKEN
    private final int LINE = 0;
    private final int CHAR = 1;
    private final int TOKEN = 2;
    private boolean stdin;
    private final static int MAXTOKSIZE = 36;
    
    /* */
    
    /**
     * Create a subclass and override this method to obtain different
     * token separation.  Your method will be passed an int
     * containing the next character in the file.  It should
     * return a boolean indicating whether that char is
     * acceptable within a token.  Chars not acceptable within
     * tokens will be treated the way white space characters
     * are currently treated.
     */
     protected
    boolean notATokenChar(int c) {
        return c=='\n' || c=='\r' || c==' '  || c=='\t' ;
    }
    
     private
     String myreadLine() {
        String retval = null;
        try {
            retval = in.readLine();
        } catch (IOException e) {
            Zio.error("cannot read line",e);
        }
        return retval;
    }

    private
    int myread() {
        int retval = Integer.MIN_VALUE;
        try {
            retval = in.read();
        } catch (IOException e) {
            Zio.error("cannot read character",e);
        }
        return retval;
    }

    /**
     * Creates an input object capable of reading from the keyboard.  The
     * command window must have the focus.  (That pretty much means the
     * user must have clicked on the window used to run the program which
     * uses this constructor.)
     * <BR> maximum token size is 36
     */
    public Input()  {
        this( MAXTOKSIZE );
    }

    /**
     * Creates an input object capable of reading from the named file.
     * <BR> maximum token size is 36
     * @param fileName the name of the file to be read, can be a path name
     */
    public Input( String fileName )  {
        this( fileName, MAXTOKSIZE );
    }

    /** 
     * Reads the next character of input.  Any character, printable or
     * not, can be read this way.  This means end of line characters, too.
     * The maximum token size has no effect on <CODE>readChar()</CODE>.
     * <P>
     * <Fl>
     * If you switch to char-by-char reading from line-by-line reading
     * the first char you will get is the first char of the line after
     * the line you just read.  If you switch to char-by-char reading
     * from token-by-token reading, the first char you will get is the
     * first white space char after the token you just read.  That
     * may be an end of line character.</Fl>
     * @return the next char of input
     */
    public final char readChar()  {
  		if( eof() ) Zio.error("attempt to readChar at end of file");
        int ch = (mode==TOKEN) ? nextChar : myread();
        mode = CHAR;
        if( ch==-1 ) {
            eof = true;
            return '\0';
        }  else {
            return (char)ch;
        }
    }

    /**
     * Reads the next line of input.
     * Use this method to read your input line by line.  Each
     * line is returned in its entirety except for the (usually
     * invisible) characters
     * used by the operating system mark the ends of lines. Lines
     * can be any length, the maximum token size has no effect here.
     * <Fl><P>  If  
     * your program switches to line mode after having read something
     * in character or token mode,  the
     * rest of the current line will be skipped and the first line
     * you get will be the one after that.
     * If your program only reads lines, this will not
     * be a problem.</Fl>
     * @return the next line of input without its trailing end of line char(s)
     */
    public final String readLine()  {
        if( eof() ) Zio.error("attempt to readLine at end of file");
        String retval = myreadLine();
        eof = retval==null;
        if( !eof && mode!=LINE ) {
            retval = myreadLine();  // first readLine cleared partial line
            eof = retval==null;
        }
        mode = LINE;
        return retval;
    }

    /**
     * Reads the next token.  
     * This method first skips white space and <I>then</I> reads a token.
     * This means that several blank lines could be skipped over and
     * thrown away before the next token is found and read.<P>
     * A token is rather like a word, it is a sequence of nonblank chars
     * that is surrounded by blanks, tabs, or line endings.  For example,
     * "hi", "23", and "R2D2".  Unlike words,
     * punctuation and numbers are considered part of tokens. So if
     * there really are quotation marks in the input, they will be 
     * found in the string returned by this method.<P>
     * <Fl>There is a maximum token size of 36 which may affect how many
     * characters are actually read.  You can override this maximum
     * token size by passing an extra parameter to a constructor.
     * <P> What is meant by a token can be changed by 
     * overriding the <CODE>notATokenChar</CODE> method.</Fl>
     * @return the next token
     */
    public final String findAndReadToken()  {
  	    if( eof() ) 
            Zio.error("attempt to findAndReadToken when eof() is true");
        if( mode!=TOKEN ) { nextChar = myread(); mode = TOKEN; }
        while( notATokenChar(nextChar) ) nextChar = myread();
        if( nextChar==-1 ) { eof = true; return null; }
        int ti = 0;
        for(;;) {
            if( ti==token.length ) Zio.error(
                "maximum token length exceeded" );
            token[ti++] = (char)nextChar;
            nextChar = myread();
            if( nextChar==-1 ) { eof = true; break; }
            if( notATokenChar(nextChar) ) break;
        }
        return new String( token, 0, ti );
    }

    /**
     * Reads the next integer.  This method actually
     * reads a token first and then translates that token to 
     * int form.
     * Returns <CODE>Integer.MIN_VALUE</CODE> if no token is found.
     * Causes an error if token cannot be translated
     * to <CODE>int</CODE> form.
     * @return the next integer
     */
    public final int findAndReadInt() {
		if( eof() ) Zio.error("attempt to findAndReadInt when eof() is true");
		String tok = findAndReadToken();
		if(eof) {
			return Integer.MIN_VALUE;
		} else {
			try {
				return Integer.parseInt(tok);
			} catch( Exception e ) {
				Zio.error(
                    "found nonblank chars that cannot be converted to int",
                    e
                );
			}
		}
        return Integer.MIN_VALUE; // might be needed if error is overridden
	}

    /**
     * Reads the next real number.  This method actually
     * reads a token first and then translates that token to 
     * double form.
     * Returns <CODE>Double.NaN</CODE> if no token is found.
     * Causes an error if token cannot be translated to
     * <CODE>double</CODE> form.
     * @return the next double
     */
    public final double findAndReadDouble() {
		if( eof() ) Zio.error("attempt to findAndReadDouble when eof() is true");
		String tok = findAndReadToken();
		if(eof) {
			return Double.NaN;
		} else {
			try {
				return Double.parseDouble(tok);
			} catch( Exception e ) {
				Zio.error(
                    "found nonblank chars that cannot be converted to double",
                    e
                );
			}
		}
        return Double.NaN;  // might be needed if error is overridden
	}

    /**
     * Returns true if the last attempt to read failed because of the 
     * end of the input was discovered during that particular read operation.
     * Usually you will use this to find the end
     * of a text file.  When reading from the keyboard, eof()'s behavior 
     * is operating system dependent.   <Fl>When using another
     * character-by-character Reader object, eof() becomes true when there
     * are no more characters to "read".</Fl>
     * @return true iff the last attempt to read failed because the
     * end of input was encountered
     */
    public final boolean eof() { return eof; }

    /**
     * Tells operating system your program is finished reading.
     * <I>Always</I> close files when you are done with them.
     * Files can be reopened with by instantiating another <CODE>Input</CODE>
     * or <CODE>Output</CODE> object.
     */
    public final void close()  {
        try {
            if( !stdin ) in.close();
        } catch (IOException e) { }
    }


  
    /**
     * Creates an input object from a File object.
     * @param file a File object
     * <BR> maximum token size is 36
     */
     public
    Input( File file ) {
        this( file, MAXTOKSIZE );
    }
    
    /**
     * Creates an input object from a File Object.
     * @param file a File object
     * @param maxTokenSize the maximum number of characters in a token
     */
     public
    Input( File file, int maxTokenSize ) {
        try {
            in = new BufferedReader( new FileReader(file) );
        } catch (IOException e) {
            Zio.error("cannot use " + file.getName() + " for input",e);
        }
        mode = LINE;
        token = new char[maxTokenSize];
        stdin = false;
    }

    /**
     * Creates an input object capable of reading from the named file.
     * @param fileName the name of the file to be read, can be a path name
     * @param maxTokenSize the maximum number of characters in a token
     */
     public
    Input( String fileName, int maxTokenSize )  {
        try {
            in = new BufferedReader( new FileReader(fileName) );
        } catch (IOException e) {
            Zio.error("cannot open " + fileName,e);
        }
        mode = LINE;
        token = new char[maxTokenSize];
        stdin = false;
    }

    /**
     * Creates an input object capable of reading from the keyboard.  The
     * command window must have the focus.  (That pretty much means the
     * user must have clicked on the window used to run the program which
     * uses this constructor.)
     * <BR> maximum token size is 36
     * @param maxTokenSize the maximum number of characters in a token
     */
     public
    Input(int maxTokenSize)  {
        in = new BufferedReader( new InputStreamReader(System.in) );
        mode = LINE;
        token = new char[maxTokenSize];
        stdin = true;
    }

    /**
     * Creates an input object capable of using any Reader object.
     * Use this constructor with a CharArrayReader or a StringReader
     * object to "read" from a character array or a string using 
     * the same Input class methods you use to read from a file or
     * a keyboard.
     * <BR> maximum token size is 36
     * @param reader any reader object
     */
    public Input( Reader reader )  {
        this( reader, MAXTOKSIZE );
    }
    
    /**
     * Creates an input object capable of using any Reader object.
     * Use this constructor with a CharArrayReader or a StringReader
     * object to "read" from a character array or a string using 
     * the same Input class methods you use to read from a file or
     * a keyboard.
     * <BR> maximum token size is 36
     * @param reader any reader object
     */
    public Input( Reader reader, int maxTokenSize )  {
        in = new BufferedReader( reader );
        mode = LINE;
        token = new char[maxTokenSize];
        stdin = false;
    }

    /**
     * Creates an Input object from any InputStream 
     * object.  Use this constructor with sock.getInputStream()
     * to perform input from a Socket object.
     * @param stream any InputStream object
     * <BR> maximum token size is 36
     */
    public Input( InputStream stream )  {
        in = new BufferedReader( new InputStreamReader( stream ) );
        mode = LINE;
        token = new char[MAXTOKSIZE];
        stdin = false;
    }

    /**
     * Creates an Input object from any InputStream 
     * object.  Use this constructor with sock.getInputStream()
     * to perform input from a Socket object.
     * @param stream any InputStream object
     * @param maxTokenSize the maximum number of characters in a token
     */
    public Input( InputStream stream, int maxTokenSize )  {
        in = new BufferedReader( new InputStreamReader( stream ) );
        mode = LINE;
        token = new char[maxTokenSize];
        stdin = false;
    }
    /* */

}

