// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax .swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * <CODE>ZWindow</CODE>s are top level windows known to the 
 * operating system.  Here is an example program that creates and displays
 * a window containing a red square. 
 * <P><PRE>
 * public static void main( String [] junk) {
 *    ZWindow g = new ZWindow(
 *                     "Red Box",
 *                     new ZBox()
                           .color(Color.RED).size(new Dimension(100,100))
 *    );
 * }
 *</PRE> <P>
 * Here is an example with two squares appearing in a row.
 * <PRE>
 * public static void main( String [] junk) {
 *    Dimension d = new Dimension(100,100);
 *    ZWindow g = new ZWindow(
 *                      "Red Box",
 *                      new ZRow(
 *                         new ZBox().color(Color.RED).size(d),
 *                         new ZBox().color(Color.BLUE).size(d)
 *                      )  
 *                );
 * }
 *</PRE> <P>
 * Replace <CODE>ZRow</CODE> with <CODE>ZCol</CODE> to get a column of squares.  
 * <CODE>ZRow</CODE>s and <CODE>ZCol</CODE>s are called slices.  Layout management
 * is handled by placing slices within slices. <P>
 * When there are multiple windows on the screen they will be placed at
 * different locations.  When a single window works out to be too big
 * for the screen, all its components are downsized.  This downsizing
 * is seldom pretty but it will let you see relative sizes.  To see
 * the exact calculated size (that is before any downsizing) of 
 * any component <CODE>ZObject</CODE>, use a <CODE>debug()</CODE> suffix on that
 * <CODE>ZObject</CODE>. (See
 * the "about slices" reference below for an explanation of what
 * suffixes are.)
 * <P>Unless a program does something to explicitly 
 * cease execution, it will run until the user closes the last visible
 * window.  The preferred way of stopping your program is to invoke 
 * <CODE>Zio.stop()</CODE>. 
 * <P><FONT SIZE="-1"><B>Imports for Both Examples: </B> 
 * <PRE>
 * import java.awt.*;  // for the Color and Dimension classes
 * import zio.*;
 * </PRE></FONT>
 * <P><FONT SIZE="-1"><B>Fine Print for the First Example: </B> 
 * The red square is created as a <CODE>ZBox</CODE> whose
 * width and height are both 100 pixels.  The window
 * shows "Red Box" in the title bar.  The window (and all windows created
 * with the zio package), will have expanding margins on all sides.  These
 * margins start out at zero width so you won't see them unless you 
 * expand the window.  You will see the red square because all zio windows
 * rigidly enforce a minimum size.</FONT>
 * <P><FONT SIZE="-1"><B>Fine Print for the Second Example: </B>
 * Here, the zero sized horizontal margins are replaced with the
 * <CODE>ZRow</CODE>'s margins.  The minimum
 * size of white space in a <CODE>ZRow</CODE> is not 0 but can
 * be adjusted.
 * <P><FONT SIZE="-1"><B>One Gotcha:</B> Do not put the same <CODE>ZObject</CODE> two
 * places in a window or windows.</FONT>
 * @see <A HREF="../../slices.html" TARGET="_top">about slices</A> 
 * @see <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Dimension.html" TARGET="_top">Dimension
 </A>, <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Color.html" TARGET="_top">Color</A>
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
class ZWindow {

//// instance & package ////

    private JFrame win;
    private Dimension minD, prefD, maxD;
    private boolean exists;
    private Color foreground = Zio.getGlobalForeground();
    private Color background = Zio.getGlobalBackground();
    private static final WindowCount windowCount = new WindowCount();
    private ZObject.ZObjects all = new ZObject.ZObjects(16);
    
    private void autoLocate(JFrame jf) { 
        windowCount.incN();
        int n = windowCount.getN();
        jf.setLocation(
            (n+minD.width>Zio.getScreenSize().width ? 0 : n),
            (n+minD.height>Zio.getScreenSize().height ? 0 : n)
        );
    }
    
    private void initializeDimensions( 
         Color foreground, 
         Color background,
         ZObject gui 
    ) {
        gui.setup(foreground,background,all);
        Dimension frameSize = Zio.getEmptyWindowSize();
        prefD = minD = new Dimension(
            gui.minD.width + frameSize.width,
            gui.minD.height + frameSize.height
        );
        maxD = new Dimension( Zio.MAX, Zio.MAX );
        Dimension largeD = Zio.getLargestZObject();
        if( minD.width>largeD.width || minD.height>largeD.height ) {
            double factor = 
                Math.min( 
                    ((double)largeD.width/minD.width),
                    ((double)largeD.height/minD.height)
                );
            all.downsize(factor);
            gui.setup(foreground,background,null);
            prefD = minD = new Dimension(
               gui.minD.width + frameSize.width,
               gui.minD.height + frameSize.height
            );
            maxD = new Dimension( Zio.MAX, Zio.MAX );
            Zio.tell(
                 "The next window won't fit on the screen as created." +
                 "\nIt will be reduced by a factor of " + factor    );
        }
        win.setSize(Zio.copyD(minD));
    }

    // maybeShutdown
    private void maybeShutdown() {
        epilog();
        windowCount.decV();
        if(windowCount.getV()<=0) Zio.stop();
    }
    
    private void makeHorizontalExpander( 
        JComponent outer, JComponent inner 
    ) {
        outer.setLayout( new BoxLayout( outer, BoxLayout.X_AXIS) );
        outer.add( Box.createHorizontalGlue() );
        outer.add( inner );
        outer.add( Box.createHorizontalGlue() );
    }
    
        
    private void makeVerticalExpander(
        JComponent outer, JComponent inner 
    ) {
        outer.setLayout(new BoxLayout( outer, BoxLayout.Y_AXIS) );
        outer.add( Box.createVerticalGlue() );
        outer.add( inner );
        outer.add( Box.createVerticalGlue() );
    }
            
    private JComponent makePane( ZObject finished ) {
        if( finished.maxD.width==Zio.MAX &&
            finished.maxD.height==Zio.MAX
        ) {
            return finished.getJCom();
        }
        ZObject cp = 
            new ZBox()
                .color(background).size(finished.minD).expandV().expandH();
        cp.setup(foreground,background,all);
        if( finished.maxD.height==Zio.MAX ) {
            makeHorizontalExpander( cp.getJCom(), finished.getJCom() );
        } else if( finished.maxD.width==Zio.MAX ) {
            makeVerticalExpander( cp.getJCom(), finished.getJCom() );
        } else {
            ZObject cp2 = 
                new ZBox()
                    .color(background).size(finished.minD).expandV();
            cp2.setup(foreground,background,all);
            makeVerticalExpander( cp2.getJCom(), finished.getJCom() );
            makeHorizontalExpander( cp.getJCom(), cp2.getJCom());
        }
        return cp.getJCom();
    }
  
    // class WindowCount
    private final static class WindowCount {
        int countVisible = 0;
        int countCreated = 0;
        int nValue = 0;
        
        synchronized void incV() { countVisible +=1; }
        
        synchronized void decV() { countVisible -=1; }
        
        synchronized int getV() { return countVisible; }

        synchronized void incN() { 
            countCreated +=1;
            nValue = 20*countCreated;
            if ( nValue>Zio.getScreenSize().width/2 ||
                 nValue>Zio.getScreenSize().height/2
            ) {
                countCreated = 1; nValue = 20;
            }
        }
        
        synchronized int getN() { return nValue; }

    } // end class WindowCount
    
    // class ResizeListener
    private class ResizeListener implements ComponentListener {

        public void componentResized(ComponentEvent e) {
            Dimension current = win.getSize();
            boolean mustDo = false;
            if( current.width < minD.width) {
                mustDo = true;
                current.width = minD.width;
            }
            if( current.height < minD.height) {
                mustDo = true;
                current.height = minD.height;
            }
            if( maxD.width<Zio.MAX && current.width > maxD.width) {
                mustDo = true;
                current.width = maxD.width;
            }
            if( maxD.height<Zio.MAX && current.height > maxD.height ) {
                mustDo = true;
                current.height = maxD.height;
            }
            if(mustDo) {
                win.setSize(current);
            }
        }

        public void componentMoved(ComponentEvent e) {
        }

        public void componentShown(ComponentEvent e) {

        }

        public void componentHidden(ComponentEvent e) {
        }
    } // end class ResizeListener

    // class ExitListener
    private class ExitListener extends WindowAdapter {

        public void windowClosing(WindowEvent e) {
            exists = false;
            maybeShutdown();
        }

    } // end class ExitListener

//// public & final ////

    /**
     * In cooperation with operating system, creates a top level window.
     * The window will contain just one <CODE>ZObject</CODE>.  Use <CODE>ZRow</CODE>
     * and <CODE>ZCol</CODE> to populate windows with multiple objects.
     * @param title the window's title
     * @param gui any ZObject
     */
    public ZWindow(String title, ZObject gui ) {
        this(title,gui,true);
    }
    
    /**
     * In cooperation with operating system, creates a top level window.
     * The window will contain just one <CODE>ZObject</CODE>.  Use <CODE>ZRow</CODE>
     * and <CODE>ZCol</CODE> to populate windows with multiple objects.
     * @param title the window's title
     * @param gui any ZObject
     * @param visible true iff the window is to be visible when created
     */
    public 
    ZWindow( String title, ZObject gui, boolean visible ) {    
        //JFrame.setDefaultLookAndFeelDecorated(true);
        win = new JFrame(title);
        win.setVisible(false);
        win.setForeground(Zio.copyC(foreground));
        win.setBackground(Zio.copyC(background));
        exists = true;
        initializeDimensions( foreground, background, gui );
        win.setContentPane(makePane(gui));
        win.addComponentListener( new ResizeListener() );
        win.addWindowListener( new ExitListener() );
        autoLocate(win);
        if( visible ) show();
    }
    
    /**
     * Closes window.
     * To "close" means to get rid of forever.
     */
    public 
    final void closeWindow() {
        if( exists ) {
            exists = false;
            maybeShutdown();
            win.dispose();
        }
    }
    
    /**
     * Defunct. Does nothing.
     * Replace with <CODE>Zio.setForegroundColor()</CODE>
     */
    public 
    final static void setForegroundColor( Color fg ) {}
    
    /**
     * Defunct. Does nothing.
     * Replace with <CODE>Zio.setBackgroundColor()</CODE>.
     */
    public 
    final static void setBackgroundColor( Color bg ) {}

    /**
     * Makes the window invisible so
     * a user will see no trace of it.
     * Undo this effect with <CODE>show()</CODE>.
     * <P><CODE>hide()</CODE> has no effect if only one 
     * window is visible. We keep one window
     * on the screen (perhaps buried by other
     * windows) to give the user the
     * ability to stop the program by 
     * closing the last window.
     */
    public
    final void hide() { 
        if( win.isVisible() && windowCount.getV()>1 ) {
            windowCount.decV(); 
            win.setVisible(false); 
        }
    }
    
    /**
     * Makes the window visible.
     * Use after <CODE>hide()</CODE>.
     */
    public
    final void show() { 
        if( !win.isVisible() ) {
            windowCount.incV();
            win.setVisible(true);
        }
    }
    
    /**
     * Moves the window.
     * Enter the coordinates of the new upper left hand
     * corner. Note that <CODE>setLocation(0,0)</CODE> would put
     * the window in upper left of the screen.
     * @param x horizontal coordinate, positive direction is to left
     * @param y vertical coordinate, positive direction is downward
     */
    public
    final void setLocation( int x, int y ) {
        win.setLocation( x, y );
    }
   
   /**
    * Makes window's minimum size full_screen. 
    * Default is a calculated size based on the 
    * minimum sizes of the components.
    */
   public final void fullScreen() {
       minD = prefD = maxD = Zio.copyD(Zio.getLargestZObject());
       setLocation(0,0);
       win.setSize(minD);
       if( win.isVisible() ) win.setVisible(true);  // force it
   }
        
   
   /**
    * Sets the window's menubar. Included for completeness but
    * as yet untested.
    */
   public
   final void setMenuBar( JMenuBar menuBar ) {
       win.setVisible(false); win.setJMenuBar(menuBar); win.setVisible(true);
   }
   
//// for subclass redefinition ////
   
   /**
    * This is invoked when a window closes (by the user or thru
    * <CODE>closeWindow()</CODE>).
    * Override it in a subclass if you want anything to happen.
    */
   protected void epilog() { }
    
}

// ref: http://java.sun.com/products/jfc/tsc/articles/merlin/windows/w2k_props.html
// HOW to make finalAction() execute when System.exit() is called??
// java -Dawt.toolkit=sun.awt.X11.XToolkit MyApp

// probably want to register windows with Zio so that Zio.stop
// can call epilog(); also add an epilog_error() for Zio.abort
// to call

