// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax.swing.*;
import java.awt.*;

/**
* Base class for slices (<CODE>ZRow</CODE>s and <CODE>ZCol</CODE>s) and <CODE>ZGrid</CODE>s..  
 * One public method is inherited from <CODE>ZObject</CODE> but not is 
 * not likely to be useful here.
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public
abstract class ZContainer extends ZObject{

//// instance & package ////

    String aboutComponents = ""; 
    boolean locked = false;
    boolean unlocked = false;
    boolean uniform = false;
    boolean spaceAtFirst = true;
    boolean spaceAtLast = true;
    
    ZObject [] gs = null;  // the contained ZObjects
    Dimension spaceMn = new Dimension(0,0);
    Dimension sliceMn = new Dimension(0,0);
    Dimension spaceMaxDelta = null;
    Dimension sliceMaxDelta = null;
    
//// superclass redefinition ////    
    
    final void debugInfo() {
        Zio.p(
            debugId + "("+name()+"): setup" +
            "\n  " + aboutComponents +
            "\n  size=" + minD + 
            "\n  maxsize=" + maxD +
            "\n  foregroundColor=" + Zio.colorToStr(desiredForeground)+
            "\n  backgroundColor=" + Zio.colorToStr(desiredBackground) +
            "\n"
            );
    }

     final void setup(  
         Color inheritedForeground,
         Color inheritedBackground,
         ZObjects all 
     ) {
        atomic = false;
        fixColor(inheritedForeground, inheritedBackground );
        piecesAndSizes(all);
        if( spaceAtFirst ) {
            getJCom().add(new Box.Filler(
               spaceMn, spaceMn, Zio.maxD(spaceMaxDelta,spaceMn)  
            ));
        }
        for( int i=0; i<gs.length; i+=1 ) {
            if(i>0) getJCom().add(new Box.Filler(
                spaceMn, spaceMn, Zio.maxD(spaceMaxDelta,spaceMn)
            ));
            getJCom().add(gs[i].getJCom());
        }
        if( spaceAtLast ) {
            getJCom().add(new Box.Filler(
                spaceMn, spaceMn, Zio.maxD(spaceMaxDelta,spaceMn)
            ));
        }
        super.setup(null,null,all);  
     }

     void downsize( double factor ) {
         sliceMn = Zio.timesD( sliceMn, factor );
         spaceMn = Zio.timesD( spaceMn, factor );
     }
     
//// for subclass redefinition ////

    abstract void piecesAndSizes(  ZObjects all  );

}

