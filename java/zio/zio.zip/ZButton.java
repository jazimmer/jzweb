// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html
package zio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
 * Implements a onscreen clickable button.  To use this
 * class effectively, you must subclass it and override
 * the <CODE>action()</CODE> method.  Here is an example with
 * two buttons whose sole function is to disable themselves
 * while enabling the other.
 * <P><PRE>
 * import zio.*;
 * 
 * public class TwoButtons {
 *  
 *     public static void main( String [] ignore ) {
 *         PassTheBuck b1 = new PassTheBuck("not me");
 *         PassTheBuck b2 = new PassTheBuck("me either");
 *         b1.introduce(b2);
 *         b2.introduce(b1);
 *         b2.disable();
 *         new ZWindow(
 *             "Pass the Buck",
 *             new ZCol( b1, b2 ).uniform()
 *         );
 *     }

 * }
 * 
 * class PassTheBuck extends ZButton {
 *     
 *     private ZButton theOtherGuy;
 *     
 *     public PassTheBuck( String label ) {
 *         super(label);
 *     }
 *     
 *     public void introduce( ZButton other ) {
 *         theOtherGuy = other;
 *     }
 *     
 *     protected void action() {
 *         theOtherGuy.enable();
 *         disable();
 *     }
 * }
 * </PRE><P>
 * This example is a bit unusual.  In practice you probably will
 * want a separate subclass for every button.  The use of 
 * the <CODE>uniform()</CODE> suffix on the column, however, is not 
 * unusual.  This is the way to get all the buttons in a column
 * (or in a row) to be a uniform size. 
  */
 public 
 class ZButton extends ZObject {    
     
//// instance & package ////

    private final SizableJButton theButton;
    private final ZButton outer = this;
    private Dimension desiredMinSize = new Dimension(0,0);
    
    private final class SizableJButton 
          extends JButton implements ActionListener 
    {
        
        public SizableJButton(String label) {
            super(label);
        }

        public void actionPerformed(ActionEvent ignore) {
            outer.action();
        }

        public Dimension getMinimumSize() { return minD; }
        public Dimension getPreferredSize() { return minD; }
        public Dimension getMaximumSize() { return maxD; }
        
        Dimension swingSize() { return super.getPreferredSize(); } 
    }
 
//// public & final ////    
    
    /**
     * Creates a <CODE>ZButton</CODE>.
     * @param label the button's label;
     */
    public ZButton( String label ) {
        if( label.equals("") ) 
            Zio.abort(
               "ZButton (" + debugId + ") requires a nonempty label."
            );
        theButton = new SizableJButton(label);  
    }
    
    /**
     * Suffix that determines the background 
     * color.  
     * @param c the desired color
     */
    public final ZButton background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }
    
    /** Suffix that sets the foreground color.
     * The foreground color is the color of the text.
     * @param c the desired color
     */
    public final ZButton foreground( Color c ) {
        suffixChek();
        desiredForeground = c;
        return this;
    }

    /**
     * Suffix that creates debug output.
     * @param debugId a string to identify this component 
     * in the debug output
     */
    public final ZButton debug( String debugId ) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }

    /**
     * Suffix which sets the font the
     * label will appear in.  
     * @param f the desired font
     */
    public final ZButton setFont(Font f) {
        suffixChek();
        theButton.setFont(f);
        return this;
    }

    /**
     * Suffix which alters the
     * point size of the font.
     * @param pointSize the desired point size
     */
    public final ZButton pointSize(int pointSize) {
        suffixChek();
        setFont(Zio.changePointSize( theButton.getFont(), pointSize ) );
        return this;
    }
    
    /** 
     * Suffix that sets the minimum size.  This suffix
     * adjusts the amount of screen real estate that the <CODE>ZButton</CODE>
     * object will fill.  The actual <CODE>Dimension</CODE> allowed
     * is obtained by taking the largest width and height 
     * found the initial text or the minimum size, if any.
     * @param minSize the desired minimum size
     */
    public final ZButton minSize( Dimension minSize ) {
        suffixChek();
        chekMinimumD(minSize,"size suffix");
        this.desiredMinSize = minSize;
        return this;
    }
    
    /**
     * Enables the button.  By
     * default button is enabled.  If
     * <CODE>disable()</CODE> has executed,
     * this sets things back to normal.
     */
    public final void enable() {
        theButton.setEnabled(true);
    }

    /**
     * Disables the button.  By
     * default button is enabled.  This
     * will cause button to appear inactive and
     * also refuse to be clicked.  Use
     * <CODE>enable()</CODE> to put button back
     * in its original state.
     */
    public final void disable() {                                         
        theButton.setEnabled(false);
    }

//// for subclass redefinition ///

    /**
     * This action is invoked whenever an enabled button is
     * clicked.  In this base class it does nothing.
     * Create a subclass and override this method to makey
     * a kind of button that respond to the user in a whatever
     * particular way you have in mind.
     */
    protected void action() { }
    
//// superclass redefinition ////
    
    final String name() { return  "ZButton"; }
    
    final void setup(
        Color inheritedForeground,
        Color inheritedBackground,
        ZObjects all
    ) {
        setJCom( theButton );
        setSize( Zio.maxD(desiredMinSize,theButton.swingSize()) );
        theButton.setFocusable(false);
        theButton.setVerticalAlignment(JButton.CENTER);
        theButton.setHorizontalAlignment(JButton.CENTER);
        theButton.setHorizontalTextPosition(JButton.CENTER);
        theButton.setVerticalTextPosition(JButton.CENTER);
        theButton.setAlignmentX(0.5F);            
        theButton.setAlignmentY(0.5F);
        theButton.addActionListener(theButton);
        super.setup(inheritedForeground,inheritedBackground,all);
    }
 
}
