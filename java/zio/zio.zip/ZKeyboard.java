// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax.swing.*;
import javax.swing.text.Caret;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;

/**
 * Defines a area for user input.
 * <P>
 * This class may be used in two ways
 * <OL> 
 * <LI> Make a subclass that overrides the <CODE>action</CODE>
 * method.  This method is invoked and given the user's
 * input whenever the user presses the enter key.
 * <LI> Create a submit button and execute this class's
 * <CODE>getText</CODE> method from it.  (Currently, this way will
 * require knowledge of Swing and a use of <CODE>ZComponent</CODE>.)
 * </OL>
 * <P>
 * An example
 * <P><CODE>
 * class MyKeyboard extends ZKeyboard {
 *     public void action(String userin) {
 *           Zio.show(userin);
 *     }
 * }
 *</CODE><P>
 * creates a class whose objects will show an 
 * input area on the screen.  When the user enters something,
 * it will appear in the command window.
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
class ZKeyboard extends ZObject {

//// instance & package ////

    private int desiredNCols = 1;
    private SizableJTextField theField;
    private boolean canOverflow = false;
    private boolean expandH = false;    // expandH => canOverflow
    
    private final KeyAdapter keyboard = new KeyAdapter() {
        public void keyPressed(KeyEvent k) {
            String t = theField.getText();
            if( k.getKeyCode()==KeyEvent.VK_ENTER ) {
                action(t);
                theField.setText("");
            } else if(! canOverflow ) {
                int cursor1 = theField.getCaret().getDot();
                theField.setText(t);  // moves caret to end
                int cursor2 = theField.getCaret().getDot();
                int cursor2Horizontal = 0;
                try {
                    cursor2Horizontal =
                        theField.modelToView(cursor2).x;
                } catch ( BadLocationException ble ) { }
                while( 
                    cursor2Horizontal>=minD.width
                    || 
                    theField.getScrollOffset()>0
                ) {
                    theField.setText( t.substring(0,t.length()-1) );
                    t = theField.getText();
                    cursor2 = theField.getCaret().getDot();
                    try {
                        cursor2Horizontal =
                            theField.modelToView(cursor2).x;
                    } catch ( BadLocationException ble ) { }
                }
                theField.getCaret().setDot(cursor1);
            }
        }
    };
 
    final class SizableJTextField extends JTextField {
        public Dimension getMinimumSize() { return minD; }
        public Dimension getPreferredSize() { return minD; }
        public Dimension getMaximumSize() { return maxD; }
        public Dimension swingSize() { return super.getPreferredSize(); }
    }

    private int estimateWidth(int numCols) {  // numCols >= 0
        StringBuffer b = new StringBuffer(numCols);
        for( int i=0; i<numCols; i+=1 ) 
            if( i%3==0 ) b.append('W');
            else         b.append('t');
        String rememberMe = theField.getText();
        theField.setText(new String(b));
        int retval = theField.swingSize().width;
        theField.setText(rememberMe);
        return retval;
    }

    //// final & public ////
  
    /**
     * Creates a <CODE>ZKeyboard</CODE> object.
     * The default data entry area is approximately
     * 25 characters.
     */
    public ZKeyboard() {
        theField = new SizableJTextField();
        numCols(25);
    }

    /**
     * Suffix which sets the font used when the user 
     * enters data in this object.
     * @param f the desired font
     */
     public
    final ZKeyboard setFont(Font f) {
        suffixChek();
        theField.setFont(f);
        return this;
    }
    
    /**
     * Suffix that sets the approximate number of
     * columns the user can enter without auto scrolling.
     * @param numColumns the desired number of columns
     */
    public final ZKeyboard numCols(int numColumns) {
        suffixChek();
        desiredNCols = numColumns; 
        return this;
    }
    
    /**
     * Suffix that determines the background 
     * color of the <CODE>ZKeyboard</CODE>.  The background
     * color will be seen in the spaces.
     * @param c the desired color
     */
    public final ZKeyboard background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }
    
    /** Suffix that sets the foreground color.
     * This is the color of the user's text entries.
     */
    public final ZKeyboard foreground( Color c ) {
        suffixChek();
        desiredForeground = c;
        return this;
    }
    
    /**
     * Suffix that creates debug output.
     * @param debugId a string to identify this <CODE>ZKeyboard</CODE>
     * in the debug output
     */
    public final ZKeyboard debug( String debugId ) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }

    /**
     * Suffix that enables user to type more text than
     * can be displayed.  
     */
    public final ZKeyboard canOverflow() {
        suffixChek();
        this.canOverflow = true;
        return this;
    }

    /**
     * Suffix that enables horizontal stretching.
     * Use this to allow the keyboard to be streched
     * in a horizontal direction when the user resizes the
     * window.  This suffix <I>also</I> does the 
     * <CODE>canOverflow()</CODE> modification.
     */
    public final ZKeyboard expandH() {
        suffixChek();
        canOverflow = expandH = true;
        return this;
    }
    
    /**
     * Suffix which alters the
     * point size of the font.
     * @param pointSize the desired point size
     */
    public
    final ZKeyboard pointSize(int pointSize) {
        suffixChek();
        setFont(Zio.changePointSize( theField.getFont(), pointSize ) );
        return this;
    }
    
    
    /**
     * Overwrites the user input area.
     * @param text what you want to see in the 
     * user input area
     */
    public
    final ZKeyboard setText( String text ) {
        theField.setText(text);
        return this;
    }
    
    /**
     * Returns the text which has been entered.  May be used like a suffix
     * but is not restricted to such use.
     * @return the text entered by the user
     */
     public
    final String getText() { return theField.getText(); }
    
//// superclass redefinition

    final String name() { return "Keyboard"; }
    
    final void setup(
        Color inheritedForeground, 
        Color inheritedBackground,
        ZObjects all
    ) {
        Dimension sSiz = theField.swingSize();
        setJCom( theField ); 
        setSize( new Dimension( 
                       estimateWidth(desiredNCols),
                       sSiz.height
                 )
        );
        if( expandH ) {
            setMaxSize( new Dimension( Zio.MAX, minD.height) );
        }
        theField.addKeyListener( keyboard );
        super.setup(inheritedForeground, inheritedBackground,all);
        theField.setSelectionColor(desiredBackground);
        theField.setSelectedTextColor(desiredForeground);
    }

//// for subclass definition ////

    /**
     * Action taken when the user presses enter.
     * Override this in a subclass to do what you
     * like.
     * @param userin the text entered by the user
     */
    protected 
    void action(String userin) { }
    
}
