// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;

/**
 * A program writeable image area.   
 * Images written after the
 * window has been constructed will be cropped if they are
 * larger than the existing area.<P>
 * If a <CODE>size()</CODE> suffix is used, that will be the size.
 * If a <CODE>minSize()</CODE> suffix is used an initial image must
 * also be given and the size will be formed from the largest
 * dimensions available.
  * <P>
 * It is an error to provide no size guidance at setup time. An
 * initial image (obtained by using <CODE>showImage()</CODE> as if
 * it were a suffix) is sufficient.
 * <Fl><P>
 * There is a mechanism for responding to mouse clicks
 * and knowing where on the image the mouse click was
 * performed. See the <CODE>action</CODE> method. </Fl>
 * <P> Sample use
 * <P><PRE>
 * ZPicture pic = 
 *    new ZPicture().showImage(InOut.readImage("MyPicture.jpg") );
 * </PRE>
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
class ZPicture extends ZObject {

    //// instance & package ////

    // class MouseActionListener
    private final class MouseActionListener extends MouseAdapter {

        public void mouseClicked(MouseEvent e) {
            if( !enableMouseAction ) return;
            //if(getJCom().isFocusable()) getJCom().grabFocus();
            if( e.getButton()==MouseEvent.BUTTON1 ) {
                action(true, e.getPoint());
            } else {
                action(false, e.getPoint());
            }
        }

        public void mousePressed(MouseEvent e) {}

        public void mouseReleased(MouseEvent e) {}

    }

    private final SizableJIcon theLabel;
    private boolean enableMouseAction = false;
    private Dimension desiredSize = null;
    private Dimension desiredMinSize = null;
    private boolean expandH = false;
    private boolean expandV = false;

    final class SizableJIcon extends JLabel {
        
        public Dimension getMinimumSize() { return minD; }
        public Dimension getPreferredSize() { return minD; }
        public Dimension getMaximumSize() { return maxD; }
        
        Dimension swingSize() { return super.getPreferredSize(); } 
    }

//// public & final ////

    /**
     * Creates a <CODE>ZPicture</CODE> with no image..
     */
     public ZPicture() {
         theLabel = new SizableJIcon();
         theLabel.setVerticalAlignment(JLabel.CENTER);
         theLabel.setHorizontalAlignment(JLabel.CENTER);
         theLabel.setHorizontalTextPosition(JLabel.CENTER);
         theLabel.setVerticalTextPosition(JLabel.CENTER);
         theLabel.setAlignmentX(0.5F);
         theLabel.setAlignmentY(0.5F);
         theLabel.setFocusable(false);
    }
    
     /**
      * Suffix that creates debug output.
      * @param debugId a string to identify this component
      * in the debug output
      */
    public ZPicture debug(String debugId) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }

    /** 
     * Suffix that sets the minimum size. With this
     * suffix the size of an image is obtained by comparing
     * the dimensions set here with those of the initial
     * image, if any.  The larger dimensions will be
     * chosen.
     * @param minSize the desired minimum size
     */
    public final ZPicture minSize( Dimension minSize ) {
        suffixChek();
        chekMinimumD(minSize,"minSize suffix");
        desiredMinSize = minSize;
        return this;
    }

    /** 
     * Suffix that sets the size.  This suffix
     * fixes the amount of screen real estate that the <CODE>ZPicture</CODE>
     * object will fill. This suffix overrides any other 
     * size determiner.
     * @param desiredSize the desired minimum size
     */
    public final ZPicture size( Dimension desiredSize ) {
        suffixChek();
        chekMinimumD(desiredSize,"size suffix");
        this.desiredSize = desiredSize;
        return this;
    }
    
    /**
     * Suffix that enables horizontal stretching.
     * Use this to allow your picture area to be streched
     * in a horizontal direction when the user resizes your
     * window.
     */
    public final ZPicture expandH() {
        suffixChek();
        expandH = true;
        return this;
    }
    
    /**
     * Suffix that enables vertical stretching.
     * Use this to allow your picture area to be streched
     * in a vertical direction when the user resizes your
     * window.
     */
    public final ZPicture expandV() {
        suffixChek();
        expandV = true;
        return this;
    }

    /**
     * Display a picture.  If used as a suffix, the
     * image given here will be a size determiner. If used
     * after window setup, the image will be cropped,
     * if necessary, to fit within the existing (possibly
     * stretched) area.
     * @param image the image to be displayed 
     */
    public final ZPicture showImage( BufferedImage image ) {
        if( image!=null )  theLabel.setIcon( new ImageIcon( image ) );
        else Zio.show("null image");
        return this;
    }
    
    /**
     * Method for causing the <CODE>action()</CODE> method to be
     * executed upon mouse clicks.
     * Has no discernable effect unless the <CODE>action()</CODE>
     * method is overridden in a subclass.
     */
    protected void enableMouseAction() { enableMouseAction = true; }
    
    //// for superclass redefinition ////
    
    /**
     * For execution when user clicks the mouse over
     * the picture.  In this base class the <CODE>action()</CODE>
     * method does nothing and is not invoked. 
     * <P> To cause this method to be invoked whenever
     * the user clicks the mouse, 
     * <OL>
     * <LI> override the method in a subclass, and
     * <LI> in the your subclass's constructor, execute 
     *  <CODE>enableMouseAction()</CODE>
     * </OL>
     * You can also execute suffixes inside this constructor rather
     * than waiting for an object to be created.  (When overriding
     * a <CODE>ZObject</CODE> class, it is usually easier to use suffixes
     * this way.)  
     * <P> The point passed to <CODE>action()</CODE>
     * has the upper lefthand corner of the component as
     * its origin.  The y coordinate is positive in a downward
     * direction.
     * @see 
     * <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/awt/Point.html">Point</A>
     * @param isLeftButton true when the clicked button was the left 
     * or "first" button
     * @param point coordinates of the point where the
     * left mouse button was released
     */
    protected void action(boolean isLeftButton, Point point) { }
    
    
//// subclass redefinition ////

    void debugInfo() {
        Zio.p(
            debugId + "(" + name() + "): setup" +
            "\n  size=" + minD + 
            "\n  maxsize=" + maxD +
            "\n  " + (expandH ? "expands" : "does not expand") + " horizontally"+
            (expandV ? "\n  expands" : "\n  does not expand") + " vertically\n"
        );
    }

    String name() { return "ZPicture"; }

    void setup(
        Color inheritedForeground,
        Color inheritedBackground,
        ZObjects all
    ) { 
        Zio.show("ZPicture setup");
        Dimension eSiz = theLabel.swingSize();
        boolean hasInitialImage =
                    eSiz!=null && eSiz.width!=0 && eSiz.height!=0;
       if( !hasInitialImage && desiredMinSize!=null ) {
           Zio.abort("ZPicture (" + debugId + ") needs an initial " +
                    "image when the minSiz() suffix is used."
           );
       if( desiredSize==null && !hasInitialImage ) {
           Zio.abort("ZPicture (" + debugId + ") needs to be"+
                     " given an image or a size before being"+
                     " place in a window."
           );
        }
        if( desiredSize!= null )
            eSiz = desiredSize;
        } else if( desiredMinSize!=null  ) {
            eSiz = Zio.maxD(eSiz,desiredMinSize);
        }
        setJCom( theLabel );
        setSize( eSiz );
        setMaxSize( new Dimension( 
            expandH ? Zio.MAX : minD.width,
            expandV ? Zio.MAX : minD.height
        ));
        if( enableMouseAction ) 
            getJCom().addMouseListener( new MouseActionListener() );
        super.setup(inheritedForeground,inheritedBackground,all);
    }

}
