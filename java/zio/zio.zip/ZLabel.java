// copyright 2005 by J Adrian Zimmer
// Licensed under the Open Software License version 2.1
// see http://jazimmer.net/source_code/java/zio.html

package zio;

import javax.swing.*;
import java.awt.*;

/**
 * An unchanging line of text.
 * There are suffixes for altering the default font or
 * changing its point size.
 * Reasonable values for the point size range between
 * 7 (very small) and 75 (very big).
 * @author  copyright 2005 by J Adrian Zimmer<BR>Licensed under the Open Software License version 2.1
 * @version Jul 22, 2005
 */
public 
class ZLabel extends ZObject {
    
//// instance & package ////
    
    private final SizableJLabel theLabel;

    final class SizableJLabel extends JLabel {
        
        public SizableJLabel(String label) {
            super(label);
        }
        
        public Dimension getMinimumSize() { return minD; }
        public Dimension getPreferredSize() { return minD; }
        public Dimension getMaximumSize() { return maxD; }
        
        Dimension swingSize() { return super.getPreferredSize(); } 
    }
    
//// public & final ////    
    
    /**
     * Creates a <CODE>ZLabel</CODE>.
     * @param label the <CODE>String</CODE> to be displayed
     */
    public ZLabel( String label ) {
        theLabel = new SizableJLabel(label);
    }
    
    /**
     * Suffix that determines the background 
     * color.  
     * @param c the desired color
     */
    public final ZLabel background( Color c ) {
        suffixChek();
        desiredBackground = c;
        return this;
    }
    
    /** Suffix that sets the foreground color.
     * This is the color of the text.
     */
    public final ZLabel foreground( Color c ) {
        suffixChek();
        desiredForeground = c;
        return this;
    }
    
    
    /**
     * Suffix that creates debug output.
     * @param debugId a string to identify this component 
     * in the debug output
     */
    public final ZLabel debug( String debugId ) {
        suffixChek();
        this.debugId = debugId;
        return this;
    }
    
    /**
     * Suffix which sets the font the
     * label will appear in.  
     * @param f the desired font
     */
     public
    final ZLabel setFont(Font f) {
        suffixChek();
        theLabel.setFont(f);
        return this;
    }

    /**
     * Suffix which alters the
     * point size of the font.
     * @param pointSize the desired point size
     */
    public
    final ZLabel pointSize(int pointSize) {
        suffixChek();
        setFont(Zio.changePointSize( theLabel.getFont(), pointSize ) );
        return this;
    }
    
    
//// subclass redefinition ////
    
    final String name() { return  "ZLabel"; }
    
    final void setup(
        Color inheritedForeground,
        Color inheritedBackground,
        ZObjects all
    ) {
        setJCom(theLabel);
        setSize(theLabel.swingSize());
        theLabel.setVerticalAlignment(JLabel.CENTER);
        theLabel.setHorizontalAlignment(JLabel.CENTER);
        theLabel.setHorizontalTextPosition(JLabel.CENTER);
        theLabel.setVerticalTextPosition(JLabel.CENTER);
        theLabel.setAlignmentX(0.5F);
        theLabel.setAlignmentY(0.5F);
        super.setup(inheritedForeground,inheritedBackground,all);
    }
    
}

        