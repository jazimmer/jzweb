To use the jar file, look through the folders used by your Java
development system for those named ext. It may be easier to find these
folders if you know that ext is included in another folder named lib.
Not all lib folders contain an ext folder. The ones that do are of
interest here.

Once you have copied the jar file to the right place(s), you can
import the zio package as you would any Java API package.

One gotcha to watch out for is:  many computers have had a Java
virtual machine for the web browser installed before they had a Java
development system installed. You may have to find the ext in this
run-time system as well as any that came with the development system.
(On the computer I am using at the moment, I found *three* lib/ext folder combinations to copy zio.jar into.)

Complete documentation for the zio package, including other ways
to install it, are described in

    http://jazimmer.net/source_code/java/zio.html


