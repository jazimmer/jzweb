import zio.*;

public class HellowOrld2 {
    
    public static void main( String [] main ) {
       String variableName = "Hellow Orld";
       Zio.show(variableName);
       variableName = "Goodbye,\nfor now.";
       Zio.show(variableName);
    }
    
}

// Exercise: do this without any variables.
// Exercise: do this with two variables.
