import zio.*;

public class HellowOrld {
    
    public static void main(String [] ignore) {
        Zio.show("Hellow Orld");
    }
    
}

