This is the order in which these examples ought to be 
studied:

HellowOrld.java
HellowOrld2.java
ShowFile.java
ShowFile2.java
Saturn.java
ThreeImages.java
EchoDialog.java
DynamicImage.java
DynamicImage2.java

