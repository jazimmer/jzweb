This file contains sections on "Installing and Running", "About Python",
and "About K12Python".

************************ Installing and Running ************************

   Drag and drop the K12Python folder to whatever drive you like.
   (You can click on MyComputer to see what drives you have.)

   Although K12Python will happily live on a hard disk or a flash drive,
   it will not be happy if you place it within another folder.

   Once you have copied your folder (by dragging and dropping it), you
   can open it (by clicking on it).  Look for a file named "python" 
   You want "python" -- no quotes and no uppercase letters. You do
   not want "pythonw".  If you see "python.exe", that is OK.  (Remember
   you are looking *in* the K12Python folder for this file.)

   If you have placed K12Python on a flash drive, you will always
   start it by double clicking on this "python" file.

   If you have placed K12Python on a fixed, hard drive, you can make
   things a little easier by  dragging and dropping this "python" file
   to your desktop.  HOLD THE RIGHT MOUSE BUTTON DOWN AS YOU DO THIS.
   You should be asked whether or not you want to create a shortcut. The
   answer is yes.  The file should not actually move.  
   
   If the python file does move you probably used the left mouse button.
   In that case use the left button to move the file back where it
   belongs and try again with the right button.

   Once the shortcut is on your desktop, you can start K12Python by
   double clicking on the shortcut.  (If you try this when K12Python is
   on a flash drive, it may work once.  It will not work another time if
   your flash drive is installed with a different drive letter.)
   

**************************** About Python ****************************

Python is an open source interpreted programming language which is
probably the best (as of 2007) at combining what beginners need with
what professionals need.

Python can be run from a "command line interpreter" as follows:

>>> 2 + 2
4
>>> def f(x):
...     return x + 2
...
>>> f(2)
4

where the >>>s and the ...s are prompts for you to type something 
and the lines that begin with something else have been typed by 
Python.  One can learn Python by playing with it.


************************** About K12Python ****************************

K12Python is an open source extension to Python which adds 

   1. The ability to save what you have been working with, including the
   values of variables. (See note below.)

   2. The ability to edit previously defined functions. (See
   K12Python_Workspaces.htm for an example.)
   
   3. K12Python imports future division.  That means 2/3 is 0.67 
   (approximately) instead of 0 which it would be in the current
   version of Python.

   4. K12Python lets you browse for folders to work in and it remembers 
   which folder you have been working in the next time you start it
   up.  This means you can organize your various projects.

   5. K12Python includes modules for rational numbers (that means
   fractions) and drawing simple graphs.  Simply do

   >>> import rational_numbers
   Installing:
    rational, numerator, denominator.
   For more information use help(rational), etc.
   >>>

   or

   >>> import graphing
   Installing:
    a Graph class; enter help(Graph) for more info
   >>>

But for these five features, K12Python, version 0.1.1, is just Python, 
version 2.5.

********************************* Note *********************************

When you start K12Python, you have the option of reloading your previous
workspace or not.  When you stop K12Python with

>>> quit()

you have the option of saving the current workspace or not.  If you stop
K12Python with a mouse click, your workspace is *not* saved. 

