""" Provides the ability to graph a function.

    Execute

    >>> import graphing

    and enter
    
    >>> help(Graph)
        
    for more details.
    
copyright 2006, J Adrian Zimmer [[ jazimmer.net ]]
Released under version 2.1 of the Open Software License
"""

import Tkinter as tk
import math
import __main__

__all__ = []

print "Installing:"

class GraphException(Exception): pass

outta_range = \
 "y out of range: x=%1.2f, y=%1.2f"

def linear(factor,x):
    return x*factor
    
def exponential(factor,x):
    if x==0:
        return 0
    elif x>0:
       return factor*math.log10(x)
    else:
       return -factor*math.log10(-x)

class Graph(tk.Frame):
    """ Draws a graph of function that has been defined in Python.
    
    Here is a simple but complete example,

    >>> def f(x): return x
    ...
    >>> gph = Graph(f)
    >>> gph.show()

    You will not be able to do anything else in Python until you close
    the window.  There are other methods you can execute before the show
    method -- they are listed below but you probably do not need them
    because a lot can be done through the way you create a Graph object.
 
    Some more examples:

    >>> Graph(f)

    draws the graph of a function named f.  All four quadrants will
    be shown with 200 x values on each side of the y axis.
    
    >>> Graph(f,width=600,height=400)

    draws the same graph in a window with 600 x positions and 400
    y positions. It doesn't matter whether you write the "width="
    or the "height=" before the other.
    
    >>> Graph(f,firstQuadrant=True)

    draws the first quadrant only.  (The number of positions stays
    the same, so you get twice as many positive values of x and y to
    look at.)
    
    >>> Graph(f,xfactor=0.1,width=800)

    makes 400 positive and negative x positions and gives each one
    the value of 0.1.
    
    A similar scaling multiplier can be established for the y values
    if you use "yfactor=" and "height=".  

    If you want a logarithmic scale on one of the axes, use
    "xfactor_with_log=" or "yfactor_with_log="  If you want to
    move the origin of the coordinate system, use "xtranslate=" and
    "ytranslate=".
        
    A message can be written for every x position that generates
    a y value that is too large or too small to graph. Turn this
    feature on with "silent=False".
    """
        
    def make_axis(me,firstQuadrant):
        if firstQuadrant:
            me.xcenter = 0
            me.ycenter = me.height
        else:
            me.canvas.create_line(me.xcenter,0,me.xcenter,me.height-1)
            me.canvas.create_line(0,me.ycenter,me.width-1,me.ycenter)

    def graph(me,f):
        if me.xcenter==0:
            ran = range(0,me.width)
        else:
            ran = range(-me.xcenter,me.xcenter+1)
        for x in ran:
            y = me.calc(f,x)
            if y:
                xT = x+me.xcenter
                yT = int(0.4999+me.ycenter-y)
                me.canvas.create_oval(xT,yT,xT+1,yT+1,outline="blue")
        
    def calc(me,f,x):
        y = me.yadj(f( me.xadj(x) ))
        if not me.silent and (y<me.ycenter-me.height or y > me.ycenter):
            print outta_range % (me.xadj(x), y)
            return None
        else:
            return y
    
    def __init__(me,f, \
                 width=400, height=300, \
                 xfactor=1, xfactor_with_log=None, \
                 yfactor=1, yfactor_with_log=None, \
                 xtranslate=None, ytranslate=None, \
                 firstQuadrant = False, silent = True
                ):
                    
        tk.Frame.__init__(me,None)
        destroy = lambda x: me.tk.call( 'destroy', x )
        map( \
             destroy, \
             me.tk.call( 'winfo', 'children', '.' ) \
          )
        me.tk.call('wm','title','.',"Graphing Window")
        me.tk.call('wm','resizable','.','false','false')

        me.silent = silent
        me.width = width
        me.height = height
        me.canvas = tk.Canvas(width=me.width,height=me.height)
        me.canvas.pack()
        if me.width % 2 == 0: me.width += 1
        if me.height % 2 == 0: me.height += 1
        me.xcenter = me.width // 2
        me.ycenter = me.height // 2
        if xtranslate: me.xcenter += xtranslate
        if ytranslate: me.ycenter -= ytranslate
        if me.xcenter<0 or me.xcenter>me.width:
            raise GraphException, \
               "origin is horizontally out of the window"
        if me.ycenter<0 or me.ycenter>me.height:
            raise GraphException, \
               "origin is vertically out of the window"
        me.make_axis(firstQuadrant)

        if xfactor_with_log:
            me.xadj = lambda z: exponential(xfactor_with_log,z)
        else:
            me.xadj = lambda z: linear(xfactor,z)
        if yfactor_with_log:
            me.yadj = lambda z: exponential(yfactor_with_log,z)
        else:
            me.yadj = lambda z: linear(yfactor,z)

        me.graph(f)

    def show(self):
       self.mainloop()

_Global = __main__.__dict__

_Global['Graph'] = Graph

print " a Graph class; enter help(Graph) for more info\n"
      

